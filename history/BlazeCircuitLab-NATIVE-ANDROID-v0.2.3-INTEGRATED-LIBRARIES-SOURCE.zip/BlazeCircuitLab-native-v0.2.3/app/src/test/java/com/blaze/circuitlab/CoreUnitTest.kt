package com.blaze.circuitlab

import com.blaze.circuitlab.core.*
import org.junit.Assert.*
import org.junit.Test

/** Android Gradle JVM unit tests. No device or physical board is represented by these tests. */
class CoreUnitTest {
    @Test fun ledCurrentRetainsAlphaNumerics() {
        val c=DemoCircuits.led()
        val result=MnaSolver.step(c,dt=0.015,time=0.015)
        assertTrue(result.message,result.ok)
        assertEquals(0.008771929825300092,result.currentIn(c.parts.single{it.ref=="R1"})!!,1e-9)
    }
    @Test fun crossingRequiresExplicitJunction() {
        val c=Circuit(wires=mutableListOf(
            Wire(a=Point(-48,0),b=Point(48,0)), Wire(a=Point(0,-48),b=Point(0,48))))
        assertEquals(2,Topology.build(c).wireNet.values.toSet().size)
        c.junctions.add(Junction(at=Point(0,0)))
        assertEquals(1,Topology.build(c).wireNet.values.toSet().size)
    }
    @Test fun validManualRouteRemovesAnAirwire() {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        assertEquals(1,BoardPlanner.preview(c).airwires.size)
        BoardRouting.add(c,PadKey(r.uuid,"2"),PadKey(d.uuid,"2"))
        assertEquals(0,BoardPlanner.preview(c).airwires.size)
    }
    @Test fun differentNetRoutingIsRejected() {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        try {
            BoardRouting.add(c,PadKey(r.uuid,"1"),PadKey(d.uuid,"1"))
            fail("Different-net copper route must fail")
        } catch(_:IllegalArgumentException) { /* expected */ }
        assertTrue(c.board.routes.isEmpty())
    }
    @Test fun deletingRoutingInSnapshotPreservesOriginal() {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        BoardRouting.add(c,PadKey(r.uuid,"2"),PadKey(d.uuid,"2"))
        val copy=c.detached();copy.board.routes.clear()
        assertEquals(1,c.board.routes.size)
    }
    @Test fun realEmbeddedLibraries() {
        assertTrue(ElectronicLibrary.presets.size>=50)
        assertTrue(FootprintCatalog.available.count{it.libraryId.startsWith("BlazeBasic:")}>=14)
        assertEquals(4,McuLibrary.boards.size)
    }
    @Test fun planningPinSurvivesDetachedProjectAndIsNotSimulated() {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        c.mcuPlan=McuPlan("arduino-uno-r3")
        McuLibrary.bind(c,"D13",r.uuid,1)
        assertEquals(1,McuLibrary.plannedNets(c).size)
        assertTrue(MnaSolver.step(c).ok)
    }
}
