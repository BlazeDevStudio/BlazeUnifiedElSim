import com.blaze.circuitlab.core.*
import java.io.File

fun main(){
    val dir=File("samples").also{it.mkdirs()}
    val circuits=listOf("LED_Current_Limiter" to DemoCircuits.led(),"RC_Charging" to DemoCircuits.rc(),"LED_Switch" to DemoCircuits.switched())
    for((name,c) in circuits){
        val sch=KiCad.export(c)
        check(KiCad.balanced(sch.schematic))
        File(dir,"$name.kicad_sch").writeText(sch.schematic)
    }
    val c=DemoCircuits.led()
    BoardPlanner.assign(c,c.parts.single{it.ref=="R1"}.uuid,"BlazeBasic:R_0805")
    BoardPlanner.assign(c,c.parts.single{it.ref=="D1"}.uuid,"BlazeBasic:LED_D3")
    val src=File("app/src/main/assets/kicad")
    val lib=mutableMapOf<String,ByteArray>()
    for(file in src.listFiles()!!.filter{it.isFile})lib[file.name]=file.readBytes()
    for(file in File(src,"BlazeBasic.pretty").listFiles()!!)lib["BlazeBasic.pretty/${file.name}"]=file.readBytes()
    File(dir,"LED_With_Libraries.zip").writeBytes(KiCadPackage.pack(c,lib))
    c.mcuPlan=McuPlan("arduino-uno-r3")
    McuLibrary.bind(c,"D13",c.parts.single{it.ref=="R1"}.uuid,1)
    File(dir,"Arduino_Uno_Pin_Planning.csv").writeText(McuLibrary.csv(c))
    println("Exported samples: ${dir.listFiles()!!.map{it.name}}")
}
