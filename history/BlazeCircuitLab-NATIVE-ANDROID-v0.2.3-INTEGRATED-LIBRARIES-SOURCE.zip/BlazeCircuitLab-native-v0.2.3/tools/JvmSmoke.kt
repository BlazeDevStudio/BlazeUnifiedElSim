import com.blaze.circuitlab.core.*
import kotlin.math.abs

fun near(actual:Double,expected:Double,eps:Double=1e-4) {
    check(abs(actual-expected)<eps) { "Expected $expected, got $actual" }
}
var checks=0
fun test(name:String,fn:()->Unit){fn();checks++;println("PASS $name")}
fun main() {
    test("original LED demo and DC current") {
        val c=DemoCircuits.led();val r=MnaSolver.step(c)
        check(r.ok){r.message};near(r.currentIn(c.parts[1])!!,3.0/342.0,5e-5)
        near(r.voltageAcross(c.parts[0])!!,-5.0)
    }
    test("original switch closed and opened"){
        val c=DemoCircuits.switched()
        val on=MnaSolver.step(c);check(on.ok){on.message}
        val onCurrent=on.currentIn(c.parts[2])!!
        c.parts.first{it.type==PartType.SW}.closed=false
        val off=MnaSolver.step(c);check(off.ok){off.message}
        check(kotlin.math.abs(off.currentIn(c.parts[2])!!)<1e-6)
        check(onCurrent>.001)
    }
    test("original RC demo transient"){
        val c=DemoCircuits.rc();var state=MnaSolver.State()
        repeat(100){i-> val s=MnaSolver.step(c,state,0.01,(i+1)*0.01);check(s.ok){s.message};state=s.state }
        check(state.capacitorVoltage.isNotEmpty())
        check(state.nodeVoltage.values.all{it.isFinite()})
    }
    test("crossing wires without junction not connected") {
        val c=Circuit(title="cross",wires=mutableListOf(Wire(a=Point(-48,0),b=Point(48,0)),Wire(a=Point(0,-48),b=Point(0,48))))
        val t=Topology.build(c);check(t.wireNet.values.distinct().size==2)
        c.junctions.add(Junction(at=Point(0,0)))
        val joined=Topology.build(c);check(joined.wireNet.values.distinct().size==1)
    }
    test("unmarked T intersection is rejected"){
        val c=Circuit(wires=mutableListOf(Wire(a=Point(-48,0),b=Point(48,0)),Wire(a=Point(0,-48),b=Point(0,0))))
        check(runCatching{Topology.build(c)}.isFailure)
        c.junctions.add(Junction(at=Point(0,0)))
        check(Topology.build(c).wireNet.values.distinct().size==1)
    }
    test("end-to-end segment connection"){
        val c=Circuit(wires=mutableListOf(Wire(a=Point(-48,0),b=Point(0,0)),Wire(a=Point(0,0),b=Point(48,0))))
        check(Topology.build(c).wireNet.values.distinct().size==1)
    }
    test("duplicate refs validation"){
        val c=DemoCircuits.led();c.parts[1].ref=c.parts[0].ref
        check(runCatching{Topology.build(c)}.isFailure)
    }
    test("no GND -> diagnostic"){
        val c=DemoCircuits.led();c.parts.removeAll{it.type==PartType.GND}
        check(MnaSolver.step(c).message.contains("GND"))
    }
    test("open disconnected circuit -> floating diagnostic"){
        val c=DemoCircuits.led();c.wires.clear();c.junctions.clear()
        check(!MnaSolver.step(c).ok)
    }
    test("KiCad serializer generated syntax"){
        val c=DemoCircuits.led();val exp=KiCad.export(c)
        check(KiCad.balanced(exp.schematic));check(exp.schematic.contains("(kicad_sch"))
        check(exp.schematic.contains("(lib_symbols"))
        check(exp.schematic.contains("\"BlazeCircuitLab:LED\""))
        check(exp.schematic.contains("(junction "))
        check(exp.warnings.isNotEmpty())
        java.io.File("tools/LED_Current_Limiter.kicad_sch").writeText(exp.schematic)
    }
    test("all original alpha demos now export KiCad symbols without fake footprints") {
        for(c in listOf(DemoCircuits.led(),DemoCircuits.rc(),DemoCircuits.switched())) {
            val exp=KiCad.export(c);check(KiCad.balanced(exp.schematic))
            check(exp.warnings.any{it.contains("physical")||it.contains("footprint")})
        }
    }
    test("KiCad deterministic output"){
        val c=DemoCircuits.led();check(KiCad.export(c).schematic==KiCad.export(c).schematic)
    }
    test("LED branch current matches original HTML alpha") {
        val c=DemoCircuits.led();val r=MnaSolver.step(c,dt=.015,time=.015)
        near(r.currentIn(c.parts[1])!!,.008771929825300092,1e-9)
    }
    test("Switch branch current matches original HTML alpha") {
        val c=DemoCircuits.switched();val r=MnaSolver.step(c,dt=.015,time=.015)
        near(r.currentIn(c.parts[2])!!,.01452131521679579,1e-9)
    }
    test("RC first timestep matches original HTML alpha") {
        val c=DemoCircuits.rc();val r=MnaSolver.step(c,dt=.015,time=.015)
        near(r.currentIn(c.parts[1])!!,.00023205148132880336,1e-9)
    }
    test("PCB data mapping uses authoritative net graph") {
        val c=DemoCircuits.led();val r=c.parts[1]
        val pads=BoardContract.resolvePads(c,listOf(PhysicalPadMapping(r.uuid,"Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal",mapOf("1" to 0,"2" to 1))))
        check(pads.size==2 && pads[0].electricalNet!=pads[1].electricalNet)
    }
    test("PCB mapping rejects invented voltage-source footprint") {
        val c=DemoCircuits.led();val p=c.parts[0]
        check(runCatching{BoardContract.resolvePads(c,listOf(PhysicalPadMapping(p.uuid,"Connector_Generic:Conn_01x02",mapOf("1" to 0,"2" to 1))))}.isFailure)
    }
    test("PCB mapping rejects missing terminal mapping") {
        val c=DemoCircuits.led();val p=c.parts[1]
        check(runCatching{BoardContract.resolvePads(c,listOf(PhysicalPadMapping(p.uuid,"Resistor_SMD:R_0805",mapOf("1" to 0))))}.isFailure)
    }
    test("PCB explicit footprint assignment builds one unrouted net") {
        val c=DemoCircuits.led()
        val resistor=c.parts.single{it.ref=="R1"};val led=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,resistor.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,led.uuid,"LED_THT:LED_D3.0mm")
        val preview=BoardPlanner.preview(c)
        check(preview.pads.size==4)
        check(preview.airwires.size==1)
        check(preview.airwires.single().a.net==preview.airwires.single().b.net)
        check(preview.warnings.any{it.contains("no physical footprint")})
    }
    test("PCB footprint pin polarity is physical KiCad LED cathode 1 anode 2") {
        val c=DemoCircuits.led();val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        val p=BoardPlanner.preview(c).pads.filter{it.ref=="D1"}.associateBy{it.pad}
        val topology=Topology.build(c)
        check(p.getValue("1").net==topology.net(d,1))
        check(p.getValue("2").net==topology.net(d,0))
    }
    test("PCB rejects impossible position and missing footprint") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        check(runCatching{BoardPlanner.assign(c,r.uuid,"LED_THT:LED_D3.0mm")}.isFailure)
        BoardPlanner.assign(c,r.uuid,"Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal")
        val pl=c.board.placements.single();pl.xMm=0.0
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("PCB layout snapshots are deep copies") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        val snap=c.detached();c.board.placements.single().xMm=20.0
        check(snap.board.placements.single().xMm!=20.0)
    }
    test("PCB has no fabricated copper traces") {
        val c=DemoCircuits.led()
        BoardPlanner.assign(c,c.parts.single{it.ref=="R1"}.uuid,"Resistor_SMD:R_0805_2012Metric")
        check(BoardPlanner.preview(c).airwires.isEmpty())
    }
    test("manual F.Cu route joins same-net pads and removes one airwire") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"}; val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        check(BoardPlanner.preview(c).airwires.size==1)
        val route=BoardRouting.add(c,PadKey(r.uuid,"2"),PadKey(d.uuid,"2"))
        check(route.layer=="F.Cu" && c.board.routes.size==1)
        check(BoardPlanner.preview(c).airwires.isEmpty())
    }
    test("different-net pad connection is rejected without mutation") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"}; val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        check(runCatching{BoardRouting.add(c,PadKey(r.uuid,"1"),PadKey(d.uuid,"1"))}.isFailure)
        check(c.board.routes.isEmpty())
    }
    test("invalid copper geometry and unsupported layers are refused") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"}; val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        val start=PadKey(r.uuid,"2");val end=PadKey(d.uuid,"2")
        c.board.routes.add(BoardRoute(start=start,end=end,bends=listOf(MmPoint(19.23,18.13))))
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
        c.board.routes.clear()
        c.board.routes.add(BoardRoute(start=start,end=end,layer="B.Cu"))
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("routing snapshots are deep copies and retain pad identities") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        BoardRouting.add(c,PadKey(r.uuid,"2"),PadKey(d.uuid,"2"))
        val snap=c.detached()
        c.board.routes.clear()
        check(snap.board.routes.size==1 && snap.board.routes.single().start==PadKey(r.uuid,"2"))
        check(BoardPlanner.preview(snap).airwires.isEmpty())
    }
    test("route becomes invalid if footprint motion would cause a diagonal segment") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        BoardRouting.add(c,PadKey(r.uuid,"2"),PadKey(d.uuid,"2"))
        c.board.placements.single{it.partUuid==d.uuid}.yMm+=1.0
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("approximate DRC refuses copper on a different-net pad") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        val first=BoardPlanner.preview(c).pads.single{it.ref=="R1" && it.pad=="1"}.at
        val second=BoardPlanner.preview(c).pads.single{it.ref=="D1" && it.pad=="1"}.at
        // This manually injected copper has endpoints on *different* nets.
        c.board.routes.add(BoardRoute(start=PadKey(r.uuid,"1"),end=PadKey(d.uuid,"1"),
            bends=if(first.x!=second.x&&first.y!=second.y)listOf(MmPoint(second.x,first.y)) else emptyList()))
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("route rejects missing pad and nonfinite geometry") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        val start=PadKey(r.uuid,"2");val end=PadKey(d.uuid,"2")
        c.board.routes.add(BoardRoute(start=PadKey(r.uuid,"999"),end=end))
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
        c.board.routes.clear()
        c.board.routes.add(BoardRoute(start=start,end=end,bends=listOf(MmPoint(Double.NaN,1.0))))
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("route cannot silently cross an obstacle pad") {
        val c=DemoCircuits.led()
        val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        // Force a different-net R1 pin-1 pad into the path of the R1-pin-2 to D1-anode route.
        // The explicitly injected detour traverses R1 pin 1 before ending at the LED.
        val pads=BoardPlanner.preview(c).pads.associateBy{it.ref+"."+it.pad}
        val obstacle=pads.getValue("R1.1").at
        val a=pads.getValue("R1.2").at
        val z=pads.getValue("D1.2").at
        c.board.routes.add(BoardRoute(start=PadKey(r.uuid,"2"),end=PadKey(d.uuid,"2"),
            bends=listOf(obstacle,MmPoint(z.x,obstacle.y))))
        check(a.x!=obstacle.x)
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("different-net intersecting copper tracks are rejected") {
        val c=Circuit(title="Cross-net routing regression")
        val a=Part(ref="R1",type=PartType.R,x=0,y=0)
        val b=Part(ref="R2",type=PartType.R,x=180,y=0)
        val d=Part(ref="R3",type=PartType.R,x=0,y=180)
        val e=Part(ref="R4",type=PartType.R,x=180,y=180)
        c.parts.addAll(listOf(a,b,d,e))
        c.wires.add(Wire(a=Point(48,0),b=Point(132,0)))
        c.wires.add(Wire(a=Point(48,180),b=Point(132,180)))
        for(p in c.parts)BoardPlanner.assign(c,p.uuid,"Resistor_SMD:R_0805_2012Metric")
        val positions=listOf(MmPoint(15.0,25.0),MmPoint(55.0,25.0),MmPoint(35.0,10.0),MmPoint(35.0,40.0))
        c.board.placements.forEachIndexed{i,pl->pl.xMm=positions[i].x;pl.yMm=positions[i].y
            if(i>=2)pl.rotation=90}
        BoardPlanner.validate(c)
        BoardRouting.add(c,PadKey(a.uuid,"2"),PadKey(b.uuid,"1"))
        check(c.board.routes.size==1)
        check(runCatching{BoardRouting.add(c,PadKey(d.uuid,"2"),PadKey(e.uuid,"1"))}.isFailure)
        check(c.board.routes.size==1)
    }
    test("unrouted airwires are not falsely classified as copper") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        check(c.board.routes.isEmpty())
        check(BoardPlanner.preview(c).airwires.size==1)
    }
    test("PCB edits do not change alpha-based solver or KiCad electrical nets") {
        val c=DemoCircuits.led()
        val before=MnaSolver.step(c)
        val schBefore=KiCad.export(c).schematic
        val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        BoardRouting.add(c,PadKey(r.uuid,"2"),PadKey(d.uuid,"2"))
        val after=MnaSolver.step(c)
        check(before.ok && after.ok)
        near(before.currentIn(r)!!,after.currentIn(r)!!,1e-12)
        check(KiCad.export(c).schematic.contains("(kicad_sch"))
        check(schBefore.contains("(kicad_sch"))
        val t=Topology.build(c)
        check(t.net(r,1)==t.net(d,0))
    }
    test("offline electronics catalog searchable and backed by real solver types") {
        check(ElectronicLibrary.presets.size>=50)
        check(ElectronicLibrary.search("330 resistor").any{it.id=="R-330"})
        check(ElectronicLibrary.search("white LED").size==1)
        check(ElectronicLibrary.presets.map{it.id}.distinct().size==ElectronicLibrary.presets.size)
        check(ElectronicLibrary.presets.map{it.simulationType}.toSet()==PartType.values().toSet())
    }
    test("catalog placement keeps electrical semantics and persistent catalog identity") {
        val c=DemoCircuits.led()
        val p=ElectronicLibrary.instantiate("R-470",0,0,c.parts)
        check(p.ref=="R2"&&p.type==PartType.R&&p.value==470.0&&p.catalogId=="R-470")
        c.parts.add(p);c.validate()
        check(runCatching{p.catalogId="C-1";c.validate()}.isFailure)
    }
    test("offline catalog refuses unknown entry") {
        check(runCatching{ElectronicLibrary.instantiate("MOSFET-FAKE",0,0,emptyList())}.isFailure)
    }
    test("bundled local KiCad footprints map two physical pads to correct terminals") {
        val dir=java.io.File("app/src/main/assets/kicad/BlazeBasic.pretty")
        val bundled=FootprintCatalog.available.filter{it.libraryId.startsWith("BlazeBasic:")}
        check(bundled.size>=14)
        for(fp in bundled){
            check(fp.terminals.keys==fp.padOffsets.keys)
            check(fp.terminals.values.toSet()==setOf(0,1))
            val file=java.io.File(dir,"${fp.libraryId.substringAfter(':')}.kicad_mod")
            check(file.exists()){"Missing bundled ${fp.libraryId}"}
            val data=file.readText();check(data.startsWith("(footprint"))
            for(pad in fp.padOffsets.keys)check(data.contains("(pad \"$pad\""))
        }
    }
    test("new physical library assignment and ratsnest operate through shared topology") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"BlazeBasic:R_0805");BoardPlanner.assign(c,d.uuid,"BlazeBasic:LED_0805")
        val pads=BoardPlanner.preview(c).pads
        check(pads.single{it.ref=="D1"&&it.pad=="1"}.net==Topology.build(c).net(d,1))
        check(BoardPlanner.preview(c).airwires.size==1)
        check(KiCad.export(c).schematic.contains("BlazeBasic:R_0805"))
    }
    test("standalone schematic ZIP contains real KiCad footprint definitions") {
        val dir=java.io.File("app/src/main/assets/kicad")
        val files=mutableMapOf<String,ByteArray>(
            "fp-lib-table" to java.io.File(dir,"fp-lib-table").readBytes(),
            "README.txt" to java.io.File(dir,"README.txt").readBytes(),
            "sym-lib-table" to java.io.File(dir,"sym-lib-table").readBytes(),
            "BlazeCircuitLab.kicad_sym" to java.io.File(dir,"BlazeCircuitLab.kicad_sym").readBytes())
        java.io.File(dir,"BlazeBasic.pretty").listFiles()!!.forEach{file->files["BlazeBasic.pretty/${file.name}"]=file.readBytes()}
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"};val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,r.uuid,"BlazeBasic:R_0805");BoardPlanner.assign(c,d.uuid,"BlazeBasic:LED_D3")
        val bytes=KiCadPackage.pack(c,files)
        val entries=mutableMapOf<String,ByteArray>()
        java.util.zip.ZipInputStream(bytes.inputStream()).use{zip->while(true){val e=zip.nextEntry?:break;entries[e.name]=zip.readBytes()}}
        check(entries.size>=17)
        check(entries.keys.any{it.endsWith(".kicad_sch")})
        check(entries["BlazeBasic.pretty/LED_D3.kicad_mod"]!!.decodeToString().contains("(pad \"2\""))
        check(entries["fp-lib-table"]!!.decodeToString().contains("KIPRJMOD"))
        check(entries["BlazeCircuitLab.kicad_sym"]!!.decodeToString().contains("kicad_symbol_lib"))
        check(KiCad.balanced(entries["BlazeCircuitLab.kicad_sym"]!!.decodeToString()))
    }
    test("all seven bundled native KiCad symbol types are present") {
        val lib=java.io.File("app/src/main/assets/kicad/BlazeCircuitLab.kicad_sym").readText()
        check(KiCad.balanced(lib))
        for(name in listOf("VDC","VSIN","R","C","LED","SW_SPST","GND"))
            check(lib.contains("(symbol \"$name\""))
        check(lib.count{it=='('}>100)
    }
    test("KiCad bundle refuses references to absent local footprint") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        r.footprint="BlazeBasic:R_0805"
        check(runCatching{KiCadPackage.pack(c,mapOf("fp-lib-table" to "x".toByteArray()))}.isFailure)
    }
    test("Arduino UNO and Nano exact named pin reference capabilities") {
        val uno=McuLibrary.board("arduino-uno-r3")!!
        check(uno.pin("D13")!!.functions.contains("SPI_SCK"))
        check(uno.pin("A4")!!.functions.contains("I2C_SDA"))
        val nano=McuLibrary.board("arduino-nano-classic")!!
        check(nano.pin("A7")!!.kind=="INPUT_ONLY")
    }
    test("ESP32 GPIO reference contains boot and input-only restrictions") {
        val esp=McuLibrary.board("esp32-devkitc-v4-wroom32e")!!
        check(esp.pin("GPIO34")!!.kind=="INPUT_ONLY")
        check(esp.pin("GPIO0")!!.caution.contains("Strapping"))
        check(esp.pin("GPIO6")==null)
        check(esp.logicVoltage==3.3)
        check(McuLibrary.searchPins(esp.id,"I2C").size==2)
    }
    test("MCU pin planner binds stable component terminal rather than unstable net index") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        c.mcuPlan=McuPlan("arduino-uno-r3")
        McuLibrary.bind(c,"D13",r.uuid,1)
        val before=McuLibrary.plannedNets(c).single()
        check(before.net==Topology.build(c).net(r,1))
        val copy=c.detached();copy.mcuPlan!!.bindings.clear()
        check(c.mcuPlan!!.bindings.size==1)
        check(McuLibrary.csv(c).contains("D13"))
        val d=c.parts.single{it.ref=="D1"}
        c.wires.removeAll{it.a==Point(432,180)||it.b==Point(504,180)}
        val after=McuLibrary.plannedNets(c).single()
        check(before.connectedTo==after.connectedTo)
        check(d.ref=="D1")
    }
    test("MCU planner rejects invalid GPIO and orphan part binding") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        c.mcuPlan=McuPlan("arduino-uno-r3")
        check(runCatching{McuLibrary.bind(c,"GND",r.uuid,0)}.isFailure)
        check(runCatching{McuLibrary.bind(c,"D1","absent",0)}.isFailure)
        check(c.mcuPlan!!.bindings.isEmpty())
        McuLibrary.bind(c,"D1",r.uuid,0)
        check(runCatching{McuLibrary.bind(c,"D2",r.uuid,5)}.isFailure)
        check(c.mcuPlan!!.bindings.size==1)
    }
    test("ESP8266 NodeMCU virtual pin planner documents real D/GPIO mapping") {
        val b=McuLibrary.board("esp8266-nodemcu-1-0")!!
        check(b.pin("D0")!!.functions.contains("GPIO16"))
        check(b.pin("D2")!!.functions.contains("GPIO4"))
        check(b.pin("D8")!!.caution.contains("boot strap"))
        check(b.pin("A0")!!.kind=="INPUT_ONLY")
        check(McuLibrary.searchPins(b.id,"I2C_SDA").single().name=="D2")
    }
    test("MCU planner warns that 3.3 V GPIO is not automatically 5 V safe") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        c.mcuPlan=McuPlan("esp32-devkitc-v4-wroom32e")
        McuLibrary.bind(c,"GPIO23",r.uuid,0)
        check(McuLibrary.plannedNets(c).single().voltageHint.contains("3.3V"))
    }

    println("SUMMARY: $checks/$checks passed")
}
