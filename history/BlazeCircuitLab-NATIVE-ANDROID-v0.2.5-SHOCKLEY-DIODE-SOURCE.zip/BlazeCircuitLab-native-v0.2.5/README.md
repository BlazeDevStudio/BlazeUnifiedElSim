# Blaze CircuitLab v0.2.5 — Native diode simulation and connected libraries

This is **native Kotlin Android development source**, continuing directly from v0.2.4. It is NOT an installable APK, a complete EveryCircuit/KiCad/Altium/Arduino replacement, or a physical safety certification. The original legacy HTML is unchanged in `legacy/` and is NOT the runtime.

## New supported engineering workflow

1. In Android, select **Diode** or **Parts Library → Semiconductor / Diodes** to place a solver-backed diode. Four distinct reverse-saturation-current presets are bundled in `app/src/main/assets/catalog/electronics.json` (now 81 total presets). All four share one Shockley model; they are not four device-validated models.
2. Connect DC source → resistor → diode → return with explicit ground and junctions. Or load **Diode demo**. Tap **Run** to calculate diode current using the nonlinear MNA engine; open the oscilloscope to observe simulated voltage, not an animation preset.
3. Select a D-type diode and use **Edit value** for saturation current Is (A), or **Diode parameters** for the ideality factor n and temperature (°C). Native JSON project schema is now **v6**, preserving v1–v5 imports and defaulting old projects' new model fields.
4. Use **Assign footprint** to choose the bundled **BlazeBasic:D_DO35_7.62** provisional through-hole footprint. Pad 1 is cathode (right terminal), pad 2 is anode (left terminal); the PCB ratsnest shares the exact electrical graph with MNA.
5. Export KiCad schematic/ZIP or experimental SPICE `.cir`. SPICE writes explicit per-diode `.model ... D(Is=... N=...)`, with one supported shared temperature. Legacy piecewise LED models remain rejected by SPICE rather than misrepresented as Shockley devices.

## Numerical model and limits

A Shockley diode uses `Id = Is × (exp(Vd/(n × kT/q)) − 1)` and its exact small-signal derivative for Newton-Raphson conductance, with damped Newton steps. `k/q = 8.617333262145e-5 V/K`. Backward-Euler capacitor/inductor models and the existing simplified LED remain unchanged. For D components: `1e−18 ≤ Is ≤ 1e−3 A`, `1 ≤ n ≤ 4`, `−40 ≤ T ≤ 125 °C`. The model deliberately omits breakdown, self-heating, temperature-dependent Is, series resistance, charge storage, and reverse recovery. It cannot be used to predict a specific semiconductor's performance without calibration. Solver nonconvergence returns an error.

## Verified here

- **78/78** command-line Kotlin core tests passed, including 14 newly added diode tests. They cover the analytical bisection reference, KCL, reverse bias, parameter validation, library records, schematic pin numbers, SPICE models, PCB pad connectivity, and unchanged LED/RC/switch regressions.
- Kotlin Android-facing source compiles against **temporary API stubs only**. This is NOT Android SDK/API compilation or execution.
- `app/src/main/assets/kicad/BlazeCircuitLab.kicad_sym`, bundled footprint files, catalog JSON, and `samples/Shockley_Diode.*` were regenerated from the authoritative Kotlin registry; see `docs/TEST-EVIDENCE-v0.2.5.txt`.

Re-run using installed JDK and Kotlin CLI:

```bash
bash tools/run-jvm-smoke.sh
bash tools/check-native-syntax-with-stubs.sh
```

To make an APK in a proper Android build environment, install JDK 17, Gradle 8.9, Android SDK platform 35 / build tools 35.0.0 and run:

```bash
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
```

The GitHub Actions workflow `.github/workflows/android-debug.yml` is present, but was **not invoked or verified** in this environment. No APK, real Android tests, physical-device tests, KiCad native opening/ERC, ngspice execution, or fabrication DRC/Gerber validation is claimed.

**Future releases**: actual Android build; nonlinear device tuning and transient reliability; MCU firmware execution remains unavailable (Arduino/ESP library is only pin-planning metadata); professional KiCad/PCB interoperability requires real EDA validation. No Codex used.
