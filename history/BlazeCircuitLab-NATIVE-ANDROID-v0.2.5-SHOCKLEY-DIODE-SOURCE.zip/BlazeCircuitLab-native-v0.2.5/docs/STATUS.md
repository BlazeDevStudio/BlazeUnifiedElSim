# Blaze CircuitLab v0.2.5 — Engineering status

**Development source, not an Android app release.**

PASS: 78/78 Kotlin/JVM tests including diode analytical/KCL and old alpha fixtures; Android-facing Kotlin compile against test stubs; bundled catalog/footprint/symbol/sample checks; source ZIP integrity.

NOT VERIFIED: Android Gradle compilation or APK, physical-device launch, KiCad CLI opening/ERC/netlist, ngspice run, actual footprint dimensions, manufacturer diode models or physical safety.

SUPPORTED: seven prior abstract/ideal circuit types plus current source, inductor, and experimental Shockley diode (10 type names including ground); offline library 81 presets, 16 original starter `.kicad_mod` footprint files, Arduino/ESP pin-planning reference boards. Experimental PCB placement/routing is NOT fabrication-ready.
