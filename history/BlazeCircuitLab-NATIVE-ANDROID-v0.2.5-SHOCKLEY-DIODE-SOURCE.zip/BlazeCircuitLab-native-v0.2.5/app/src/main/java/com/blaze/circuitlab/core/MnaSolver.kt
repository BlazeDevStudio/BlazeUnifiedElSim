package com.blaze.circuitlab.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.ln

/** Bounded educational MNA: backward-Euler reactive elements, Shockley diodes, legacy piecewise LEDs. Not ngspice. */
object MnaSolver {
    /** Is in amperes, n dimensionless, T in Celsius. Fixed-Is temperature model, no breakdown/series R/capacitance. */
    object DiodeModel {
        private const val BOLTZMANN_OVER_Q = 8.617333262145e-5 // V/K
        fun thermalVoltage(celsius:Double,ideality:Double)=(celsius+273.15)*BOLTZMANN_OVER_Q*ideality
        fun current(voltage:Double,isA:Double,ideality:Double,celsius:Double):Double {
            val vT=thermalVoltage(celsius,ideality)
            return isA * (exp((voltage/vT).coerceIn(-80.0,40.0))-1.0)
        }
        fun conductance(voltage:Double,isA:Double,ideality:Double,celsius:Double):Double {
            val vT=thermalVoltage(celsius,ideality)
            return isA / vT * exp((voltage/vT).coerceIn(-80.0,40.0))
        }
    }
    data class State(val capacitorVoltage: Map<String,Double> = emptyMap(), val nodeVoltage: Map<Int,Double> = emptyMap(),
        val inductorCurrent: Map<String,Double> = emptyMap())
    data class Result(
        val ok: Boolean, val message: String, val topology: Topology.NetGraph?,
        val voltage: Map<Int,Double> = emptyMap(), val current: Map<String,Double> = emptyMap(),
        val state: State = State(), val iterations: Int = 0, val time: Double = 0.0
    ) {
        fun voltageAcross(p:Part):Double? = topology?.let{ t ->
            if(p.type==PartType.GND) 0.0 else (voltage[t.net(p,0)]?:return null)-(voltage[t.net(p,1)]?:return null)
        }
        fun currentIn(p:Part) = current[p.uuid]
    }
    private fun solveLinear(a:Array<DoubleArray>,b:DoubleArray):DoubleArray {
        val n=b.size
        val m=Array(n){i->DoubleArray(n+1){j->if(j==n)b[i] else a[i][j]}}
        for(k in 0 until n){
            var pivot=k;for(i in k+1 until n)if(abs(m[i][k])>abs(m[pivot][k]))pivot=i
            if(abs(m[pivot][k])<1e-13)throw IllegalArgumentException("Singular circuit matrix or incompatible ideal voltage sources")
            if(pivot!=k){val tmp=m[k];m[k]=m[pivot];m[pivot]=tmp}
            val div=m[k][k];for(j in k..n)m[k][j]/=div
            for(i in 0 until n)if(i!=k){val factor=m[i][k];if(factor!=0.0)for(j in k..n)m[i][j]-=factor*m[k][j]}
        }
        return DoubleArray(n){m[it][n]}
    }
    private fun verifyGroundReachability(circuit:Circuit,t:Topology.NetGraph) {
        val g=t.groundNet?:throw IllegalArgumentException("Add a GND reference before simulating")
        val neighbors=mutableMapOf<Int,MutableSet<Int>>()
        for(p in circuit.parts)if(p.type!=PartType.GND){
            val a=t.net(p,0);val b=t.net(p,1)
            neighbors.getOrPut(a){mutableSetOf()}.add(b)
            neighbors.getOrPut(b){mutableSetOf()}.add(a)
        }
        val seen=mutableSetOf(g);val queue=ArrayDeque<Int>();queue.add(g)
        while(queue.isNotEmpty())for(v in neighbors[queue.removeFirst()].orEmpty())if(seen.add(v))queue.add(v)
        val used=circuit.parts.flatMap{p->p.pins().indices.map{i->t.net(p,i)}}
        if(used.any{it !in seen})throw IllegalArgumentException("Floating circuit island: connect the network to GND")
    }
    fun step(circuit:Circuit,state:State=State(),dt:Double=.015,time:Double=0.0):Result {
        var topology:Topology.NetGraph?=null
        try {
            require(dt.isFinite() && dt>0 && dt<=1.0) { "Invalid simulation timestep" }
            topology=Topology.build(circuit)
            val t=topology
            verifyGroundReachability(circuit,t)
            val ground=t.groundNet!!
            val roots=circuit.parts.flatMap{p->p.pins().indices.map{i->t.net(p,i)}}.distinct().filter{it!=ground}.sorted()
            val idx=roots.withIndex().associate{it.value to it.index}
            val sources=circuit.parts.filter{it.type==PartType.V||it.type==PartType.AC}
            val n=roots.size+sources.size
            require(n in 1..120){"Unsupported circuit size or missing active network"}
            fun node(net:Int):Int=if(net==ground)-1 else idx[net]?:throw IllegalStateException("Net missing from MNA")
            fun sourceVoltage(p:Part):Double=if(p.type==PartType.AC)p.value*sin(2*PI*p.frequency*time) else p.value
            var previous=state.nodeVoltage
            var solution=DoubleArray(n)
            var volts=emptyMap<Int,Double>()
            var iterations=0
            var converged=false
            val physicalDiodes=circuit.parts.filter{it.type==PartType.D}
            for(iter in 0 until if(physicalDiodes.isEmpty())24 else 80) {
                iterations=iter+1
                val A=Array(n){DoubleArray(n)};val b=DoubleArray(n)
                fun stampG(a:Int,z:Int,g:Double){
                    val x=node(a);val y=node(z)
                    if(x>=0)A[x][x]+=g
                    if(y>=0)A[y][y]+=g
                    if(x>=0&&y>=0){A[x][y]-=g;A[y][x]-=g}
                }
                fun stampI(a:Int,z:Int,i:Double){val x=node(a);val y=node(z);if(x>=0)b[x]-=i;if(y>=0)b[y]+=i}
                for(i in roots.indices)A[i][i]+=1e-11 // Numerical regularization; floating networks rejected above.
                for(p in circuit.parts) {
                    if(p.type==PartType.GND)continue
                    val a=t.net(p,0);val z=t.net(p,1)
                    when(p.type){
                        PartType.R -> stampG(a,z,1/p.value)
                        PartType.SW -> stampG(a,z,if(p.closed)20.0 else 1e-10)
                        PartType.I -> stampI(a,z,p.value) // Positive I flows pin 0 (left) to pin 1 (right).
                        PartType.L -> {
                            // Backward Euler Norton equivalent: i_n = i_(n-1) + (dt/L)*v_n.
                            // Unlike a capacitor, the inductor stores branch CURRENT.
                            val g=dt/p.value
                            stampG(a,z,g)
                            stampI(a,z,state.inductorCurrent[p.uuid]?:0.0)
                        }
                        PartType.C -> {
                            val g=p.value/dt
                            stampG(a,z,g);stampI(a,z,-g*(state.capacitorVoltage[p.uuid]?:0.0))
                        }
                        PartType.D -> {
                            val v=(previous[a]?:0.0)-(previous[z]?:0.0)
                            val gd=DiodeModel.conductance(v,p.value,p.diodeIdeality,p.temperatureC)
                            val id=DiodeModel.current(v,p.value,p.diodeIdeality,p.temperatureC)
                            stampG(a,z,gd+1e-12) // tiny off-state leakage regularizer; counted in branch current
                            stampI(a,z,id-gd*v-1e-12*v)
                        }
                        PartType.LED -> {
                            val v=(previous[a]?:0.0)-(previous[z]?:0.0)
                            val on=v>=p.value
                            val g=if(on)1.0/12.0 else 1e-8
                            stampG(a,z,g)
                            if(on)stampI(a,z,-g*p.value)
                        }
                        else -> Unit
                    }
                }
                for((j,p) in sources.withIndex()){
                    val a=node(t.net(p,0));val z=node(t.net(p,1));val c=roots.size+j
                    if(a>=0){A[a][c]++;A[c][a]++};if(z>=0){A[z][c]--;A[c][z]--}
                    b[c]=-sourceVoltage(p) // Original alpha positive terminal is on the RIGHT.
                }
                solution=solveLinear(A,b)
                volts=buildMap{put(ground,0.0);roots.forEachIndexed{i,r->put(r,solution[i])}}
                // Damped Newton: bound each diode voltage update to 0.18 V to avoid runaway exponential steps.
                // Pure linear/legacy circuits preserve their prior unmodified solve path and results.
                val alpha = if(physicalDiodes.isEmpty()) 1.0 else {
                    val jump=physicalDiodes.maxOf { d ->
                        val a=t.net(d,0);val z=t.net(d,1)
                        abs(((volts[a]?:0.0)-(volts[z]?:0.0)) - ((previous[a]?:0.0)-(previous[z]?:0.0)))
                    }
                    if(jump<=0.18)1.0 else 0.18/jump
                }
                val relaxed=if(alpha==1.0)volts else buildMap<Int,Double> {
                    put(ground,0.0)
                    roots.forEach{r->put(r,(previous[r]?:0.0)+alpha*((volts[r]?:0.0)-(previous[r]?:0.0)))}
                }
                val delta=roots.maxOfOrNull{abs((previous[it]?:0.0)-(relaxed[it]?:0.0))}?:0.0
                previous=relaxed
                if(delta<1e-7){converged=true;break}
            }
            if(!converged)throw IllegalArgumentException("Nonlinear diode iteration did not converge")
            val currents=mutableMapOf<String,Double>();val caps=state.capacitorVoltage.toMutableMap()
            val inductors=state.inductorCurrent.toMutableMap()
            for(p in circuit.parts){
                if(p.type==PartType.GND)continue
                val v=(volts[t.net(p,0)]?:0.0)-(volts[t.net(p,1)]?:0.0)
                val i=when(p.type){
                    PartType.R->v/p.value
                    PartType.I->p.value
                    PartType.L->{val i=(state.inductorCurrent[p.uuid]?:0.0)+dt/p.value*v;inductors[p.uuid]=i;i}
                    PartType.SW->v/(if(p.closed)0.05 else 1e10)
                    PartType.C->{val i=p.value/dt*(v-(state.capacitorVoltage[p.uuid]?:0.0));caps[p.uuid]=v;i}
                    PartType.D->DiodeModel.current(v,p.value,p.diodeIdeality,p.temperatureC)+1e-12*v
                    PartType.LED->if(v>=p.value)(v-p.value)/12.0 else v*1e-8
                    PartType.V,PartType.AC->solution[roots.size+sources.indexOf(p)]
                    PartType.GND->0.0
                }
                if(!i.isFinite())throw IllegalArgumentException("Nonfinite branch current")
                currents[p.uuid]=i
            }
            return Result(true,"OK",t,volts,currents,State(caps,volts,inductors),iterations,time)
        } catch(e:Exception) {return Result(false,e.message?:"Numerical solver failure",topology,time=time)}
    }
}
