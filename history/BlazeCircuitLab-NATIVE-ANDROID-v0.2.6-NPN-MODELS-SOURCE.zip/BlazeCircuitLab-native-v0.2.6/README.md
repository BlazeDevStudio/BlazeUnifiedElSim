# Blaze CircuitLab v0.2.6 — Native Android transistor development source

Blaze CircuitLab is a **native Kotlin Android electronics laboratory in development**. It continues the v0.2.5 source; the unchanged original HTML alpha is archived under `legacy/` and is **not** the runtime. **This ZIP contains no APK.** It is not a mature equivalent to EveryCircuit, KiCad, Altium, and Arduino, nor a replacement for electrical or fabrication safety checks.

## Implemented in this update

- **NPN transistor circuit element (`QNPN`):** first three-terminal device, with base (terminal 0), collector (1), and emitter (2). The modified nodal analysis solver uses a simplified, temperature-adjusted **Ebers–Moll** nonlinear model with analytic Jacobian and damped iterations.
- **Native editor:** searchable NPN component presets, symbol, touch placement, optional model controls, VCE/collector-current readout, and a loaded common-emitter bias demo.
- **Component/footprint/exports:** four β presets (50/100/200/400), provisional E/B/C 3-pad footprint, KiCad native symbol entry, preliminary KiCad schematic serialization, and `.model ... NPN` / Q-line in SPICE output.
- **Version 7 project schema:** retains v1–v6 migration paths; stores transistor Is, reverse β, and modeled temperature. Existing v0.2.5 diode and original LED, RC, switch behavior is unchanged in numerical regressions.

**Engineering model limits:** β is forward common-emitter gain in the model, Is is a fixed transport saturation current, reverse β models reverse transport, and temperature changes thermal voltage only. No Early effect, capacitances, avalanche/breakdown, self-heating, charge storage, measured device parameters, temperature-dependent Is, or manufacturing verification. The new footprint is for **pin-number mapping and early placement only**. Verify the actual component datasheet and physical layout. Current results are educational estimates, not production electronics acceptance.

## Local tests completed

- `bash tools/run-jvm-smoke.sh` — **89/89 Kotlin tests PASS** (78 carried forward plus 11 new NPN tests). Includes NPN current and voltage operating points, KCL, Jacobian finite differences, turn-off, validation, library identity, three-pad wiring, KiCad/SPICE serialization, clone metadata, and original alpha numerical regressions.
- `bash tools/check-native-syntax-with-stubs.sh` — **PASS**. This uses temporary Android API stubs to check Kotlin compilation; it is NOT Android SDK compilation, APK validation or device launch.
- Bundled catalogs and sample files regenerated from authoritative Kotlin model registries. Generated standalone KiCad/ZIP/SPICE files have syntax-level checks only; **native KiCad CLI, ngspice and actual Android SDK build could not be executed here**.

## Reproduce Kotlin tests

Requires JDK 17 and Kotlin/JVM CLI in PATH:

```bash
bash tools/run-jvm-smoke.sh
bash tools/check-native-syntax-with-stubs.sh
```

## Build the Android application (external development machine or CI)

Prerequisites: Android SDK platform 35, Android build-tools 35.0.0, JDK 17, Gradle 8.9. This source does not include a generated Gradle wrapper or prebuilt Gradle distribution. From the project directory:

```bash
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
```

If build succeeds, the debug APK is at `app/build/outputs/apk/debug/app-debug.apk`. Do not call it installable until compiled and launched in a real Android runtime. The GitHub Actions workflow in `.github/workflows/android-debug.yml` is a candidate workflow, **not executed here**.

## Important unimplemented functions

No Arduino/ESP instruction emulation, compiled firmware execution, manufacturer-qualified device libraries, full KiCad verification, native Gerber/Excellon pipeline, production-grade PCB DRC, or proven physical device accuracy. PCB routing is experimental, and browser-independent native Android runtime testing is still a release gate.

Original files and previous milestone evidence are preserved in the source tree. No Codex was used.
