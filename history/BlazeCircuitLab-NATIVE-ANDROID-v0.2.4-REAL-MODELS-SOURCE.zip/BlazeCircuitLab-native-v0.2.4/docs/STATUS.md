# Blaze CircuitLab v0.2.4 — verified evidence (local)

- JVM regression: 64/64 passed in this environment after edits. See `docs/TEST-EVIDENCE-v0.2.4.txt`.
- Native Android Kotlin API-stub compile: passed (not APK compilation).
- 77 electronics presets covering nine numerical model classes; 15 bundled original BlazeBasic footprints and nine KiCad symbols, four MCU board pin maps.
- KiCad serializer and preliminary SPICE files: syntax/structural tests passed; NOT verified in native KiCad or ngspice.
- Legacy HTML alpha: preserved, SHA256 compared with v0.2.3 source.
- Android APK: not built. Android emulator/physical device: not tested. No Android SDK or Gradle executable available.
- PCB fabrication: unsupported. MCU firmware emulator: unsupported. No production-ready claims.
