package com.blaze.circuitlab

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.InputType
import android.widget.Toast
import com.blaze.circuitlab.core.*
import java.io.File
import android.util.AtomicFile
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Native Android, offline. No WebView, network permission, account, or cloud service. */
class MainActivity:Activity() {
    private lateinit var editor:NativeCircuitView
    private lateinit var readout:TextView
    private lateinit var inspector:TextView
    private lateinit var playButton:Button
    private var running=false
    private var time=0.0
    private var revision=0
    private var state=MnaSolver.State()
    private var lastResult:MnaSolver.Result?=null
    private val worker=Executors.newSingleThreadExecutor()
    private val busy=AtomicBoolean(false)
    private val handler=Handler(Looper.getMainLooper())
    private val undo=ArrayDeque<Circuit>()
    private var exportPayload:String?=null
    private val jsonFile by lazy{File(filesDir,"active-circuit.json")}
    private val atomic by lazy{AtomicFile(jsonFile)}
    private val timer=object:Runnable{
        override fun run(){
            if(running&&!busy.getAndSet(true)){
                val project=editor.project.detached()
                val savedState=state;val epoch=revision;val nextTime=time+.015
                worker.execute{
                    val result=MnaSolver.step(project,savedState,.015,nextTime)
                    handler.post {
                        if(epoch==revision){
                            lastResult=result;editor.measurement=result
                            if(result.ok){state=result.state;time=nextTime
                                val sel=editor.selectedPart()?:editor.project.parts.firstOrNull{it.type!=PartType.GND}
                                editor.addTrace(sel?.let{result.voltageAcross(it)}?:0.0)
                            }else running=false
                            editor.running=running
                            updateDisplay()
                        }
                        busy.set(false)
                    }
                }
            }
            handler.postDelayed(this,55)
        }
    }
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.rgb(8,17,29)
        window.navigationBarColor=Color.rgb(8,17,29)
        buildScreen()
        val loaded=runCatching{if(jsonFile.exists())ProjectJson.decode(atomic.readFully().toString(Charsets.UTF_8)) else DemoCircuits.led()}
            .getOrElse { DemoCircuits.led().also{show("Autosave could not load; original file retained")} }
        editor.project=loaded;editor.selected=loaded.parts.firstOrNull{it.type==PartType.LED}?.uuid
        updateDisplay();handler.post(timer)
    }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun btn(label:String,onClick:()->Unit):Button=Button(this).apply{
        text=label;textSize=12f;isAllCaps=false;minHeight=dp(45)
        setOnClickListener{onClick()}
    }
    private fun label(text:String,size:Float=13f):TextView=TextView(this).apply{
        this.text=text;setTextColor(Color.rgb(215,235,248));textSize=size
        setPadding(dp(10),dp(7),dp(10),dp(7))
    }
    private fun makeStrip():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
    private fun scrollStrip(vararg views:View):View=HorizontalScrollView(this).apply{
        isHorizontalScrollBarEnabled=false
        addView(makeStrip().apply{views.forEach{addView(it)}})
    }
    private fun buildScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(8,17,29))}
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, insets ->
            @Suppress("DEPRECATION")
            v.setPadding(0,insets.systemWindowInsetTop,0,insets.systemWindowInsetBottom)
            insets
        }
        root.addView(label("ϟ  BLAZE CIRCUITLAB   •   NATIVE ANDROID  •   v0.2 foundation",16f))
        playButton=btn("▶ Run"){running=!running;updateDisplay()}
        root.addView(scrollStrip(playButton,
            btn("Step"){running=false;simulateOnce();updateDisplay()},
            btn("Reset"){running=false;state=MnaSolver.State();time=0.0;editor.trace.clear();simulateOnce()},
            btn("Circuit"){editor.showScope=false},btn("Lab: Scope"){editor.showScope=true},
            btn("Fit"){editor.fit()},btn("Undo"){undoEdit()},btn("New"){newCircuit()}))
        val palette=mutableListOf<View>()
        val names=listOf("Select" to NativeCircuitView.Tool.SELECT,"Pan" to NativeCircuitView.Tool.PAN,
            "Wire" to NativeCircuitView.Tool.WIRE,"Junction" to NativeCircuitView.Tool.JUNCTION,
            "DC" to NativeCircuitView.Tool.V,"AC" to NativeCircuitView.Tool.AC,"R" to NativeCircuitView.Tool.R,
            "C" to NativeCircuitView.Tool.C,"LED" to NativeCircuitView.Tool.LED,
            "Switch" to NativeCircuitView.Tool.SW,"GND" to NativeCircuitView.Tool.GND)
        names.forEach{(name,mode)->palette.add(btn(name){editor.tool=mode;show("Tool: $name")})}
        root.addView(scrollStrip(*palette.toTypedArray()))
        editor=NativeCircuitView(this)
        root.addView(editor,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))
        readout=label("Solver ready",12f)
        root.addView(readout)
        inspector=label("Select a component for measurements",12f)
        root.addView(inspector)
        root.addView(scrollStrip(
            btn("Edit value"){changeValue()},btn("Toggle switch"){toggleSwitch()},
            btn("Rotate 90°"){rotateSelection()},btn("Delete"){deleteSelection()},
            btn("LED demo"){install(DemoCircuits.led())},btn("RC demo"){install(DemoCircuits.rc())},
            btn("Switch demo"){install(DemoCircuits.switched())}))
        root.addView(scrollStrip(
            btn("Save JSON"){exportJson()},btn("Import JSON"){importJson()},
            btn("Export KiCad"){exportKiCad()},btn("Project info"){showProjectInfo()}))
        editor.onCircuitChanged={edited()}
        editor.onSelectionChanged={updateDisplay()}
        editor.onUndoSnapshot={c->snapshot(c)}
        editor.onInvalidEdit={msg->show("Connection rejected: $msg")}
    }
    private fun show(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun snapshot(c:Circuit=editor.project.detached()){undo.addLast(c);if(undo.size>50)undo.removeFirst()}
    private fun undoEdit(){if(undo.isEmpty()){show("Nothing to undo");return};editor.project=undo.removeLast();edited()}
    private fun install(c:Circuit){snapshot();editor.project=c;edited()}
    private fun newCircuit(){install(Circuit())}
    private fun edited(){
        revision++;state=MnaSolver.State();lastResult=null;editor.trace.clear();time=0.0
        saveAutosave();simulateOnce();updateDisplay()
    }
    private fun saveAutosave(){
        var output:java.io.FileOutputStream?=null
        try {
            val bytes=ProjectJson.encode(editor.project).toByteArray(Charsets.UTF_8)
            output=atomic.startWrite()
            output.write(bytes)
            atomic.finishWrite(output)
            output=null
        } catch(e:Exception) {
            if(output!=null)atomic.failWrite(output)
            show("Autosave failed: ${e.message}; export a backup")
        }
    }
    private fun simulateOnce(){
        val result=MnaSolver.step(editor.project.detached(),state,.015,time)
        lastResult=result;editor.measurement=result
        if(result.ok)state=result.state
        updateDisplay()
    }
    private fun updateDisplay(){
        if(!::editor.isInitialized)return
        playButton.text=if(running)"Ⅱ Pause" else "▶ Run"
        val r=lastResult
        readout.text=if(r==null)"Waiting for simulator" else if(!r.ok)"Solver: ${r.message}"
            else "MNA · ${r.iterations} iterations · t=${String.format(Locale.US,"%.2f",time)} s · ${editor.project.parts.size} components"
        val p=editor.selectedPart()
        inspector.text=if(p==null)"No component selected · PCB and firmware modes are not implemented yet"
            else {
                val v=r?.voltageAcross(p);val i=r?.currentIn(p)
                "${p.ref} (${p.type}) · Value ${p.value} · V=${v?.let{String.format(Locale.US,"%.3f",it)}?:"—"} V · I=${i?.let{String.format(Locale.US,"%.6f",it)}?:"—"} A"
            }
        editor.invalidate()
    }
    private fun changeValue(){
        val p=editor.selectedPart()?:return show("Select a component first")
        if(p.type==PartType.GND||p.type==PartType.SW)return show("This component has no editable numeric value")
        val input=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(p.value.toString());setSelection(text.length)}
        AlertDialog.Builder(this).setTitle("${p.ref} · ${p.type} value")
            .setView(input).setPositiveButton("Apply"){_,_->
                val v=input.text.toString().toDoubleOrNull()
                if(v==null||!v.isFinite()||(p.type in setOf(PartType.R,PartType.C,PartType.LED)&&v<=0.0))show("Invalid electrical parameter")
                else {
                    val old=p.value
                    p.value=v
                    val valid=runCatching{editor.project.validate()}
                    if(valid.isFailure){p.value=old;show(valid.exceptionOrNull()?.message?:"Invalid value")}
                    else {p.value=old;snapshot();p.value=v;edited()}
                }
            }.setNegativeButton("Cancel",null).show()
    }
    private fun toggleSwitch(){
        val p=editor.selectedPart()?:return show("Select a switch first")
        if(p.type!=PartType.SW)return show("Selected component is not a switch")
        snapshot();p.closed=!p.closed;edited()
    }
    private fun rotateSelection(){
        val p=editor.selectedPart()?:return show("Select a component first")
        val old=editor.project.detached()
        val previousPins=p.pins();p.rotation=(p.rotation+90)%360
        val newPins=p.pins()
        // Re-anchor original wire endpoints at the same physical pins after rotation.
        for(w in editor.project.wires){for(i in previousPins.indices){if(w.a==previousPins[i])w.a=newPins[i]
            if(w.b==previousPins[i])w.b=newPins[i]}}
        // Stay fail-closed until arbitrary multi-segment re-routing is validated.
        if(editor.project.wires.any{it.a.x!=it.b.x && it.a.y!=it.b.y}){
            editor.project=old;show("Rotation would create diagonal wires; disconnect or reroute first");return
        }
        try{Topology.build(editor.project);snapshot(old);edited()}
        catch(e:Exception){editor.project=old;show("Rotation rejected: ${e.message}")}
    }
    private fun deleteSelection(){
        val p=editor.selectedPart()?:return show("Select a component first")
        snapshot();editor.project.parts.remove(p);editor.selected=null;edited()
    }
    private fun exportJson(){exportPayload=runCatching{ProjectJson.encode(editor.project)}.getOrElse{return show("Export failed: ${it.message}")}
        chooseSave("application/json","${safeName()}.json",101)}
    private fun exportKiCad(){
        val exported=runCatching{KiCad.export(editor.project)}.getOrElse{return show("KiCad export rejected: ${it.message}")}
        exportPayload=exported.schematic
        AlertDialog.Builder(this).setTitle("Experimental KiCad 9 schematic")
            .setMessage(exported.warnings.joinToString("\n"))
            .setPositiveButton("Export .kicad_sch"){_,_->chooseSave("application/octet-stream","${safeName()}.kicad_sch",102)}
            .setNegativeButton("Cancel",null).show()
    }
    private fun safeName()=editor.project.title.replace(Regex("[^a-zA-Z0-9_-]"),"_").take(54).ifEmpty{"Circuit"}
    private fun chooseSave(type:String,name:String,req:Int){
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);this.type=type;putExtra(Intent.EXTRA_TITLE,name)}
        startActivityForResult(intent,req)
    }
    private fun importJson(){val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"}
        startActivityForResult(intent,103)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK)return
        val uri:Uri=data?.data?:return
        try{
            if(requestCode==103){
                val json=contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use{reader->
                    val out=StringBuilder();val chunk=CharArray(4096)
                    while(true){val n=reader.read(chunk);if(n<0)break
                        if(out.length+n>2_000_000)throw IllegalArgumentException("File exceeds import size limit")
                        out.append(chunk,0,n)}
                    out.toString()
                }
                val parsed=ProjectJson.decode(json)
                install(parsed);show("Circuit imported")
            } else if(requestCode==101||requestCode==102){
                val payload=exportPayload?:return
                contentResolver.openOutputStream(uri,"wt")!!.use{stream->stream.write(payload.toByteArray(Charsets.UTF_8));stream.flush()}
                show("Saved through Android file picker")
            }
        }catch(e:Exception){show("File operation failed: ${e.message}")}
        finally{exportPayload=null}
    }
    private fun showProjectInfo(){AlertDialog.Builder(this).setTitle("Blaze CircuitLab · Native foundation")
        .setMessage("Implemented: Android Canvas editor, DC/AC source, R, C, approximate LED, switch, explicit junctions, MNA, oscilloscope, offline autosave, JSON and experimental KiCad schematic export.\n\nNot implemented: PCB editor, real MCU emulation, Gerber, professional SPICE-level accuracy.\n\nOffline. No account. No WebView.")
        .setPositiveButton("OK",null).show()}
    override fun onPause(){running=false;saveAutosave();super.onPause()}
    override fun onDestroy(){handler.removeCallbacks(timer);worker.shutdownNow();super.onDestroy()}
}
