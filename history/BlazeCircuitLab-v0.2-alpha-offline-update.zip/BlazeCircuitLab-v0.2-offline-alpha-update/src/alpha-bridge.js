/* Blaze CircuitLab 0.1 -> 0.2 bridge. One native graph drives both MNA and KiCad.
 * Do not treat these export tests as native KiCad verification.
 */
(function(root){ 'use strict';
 const core=root.BlazeCoreTopology, ki=root.BlazeKiCad;
 const SCALE=5.08/48, snap=n=>Math.round(n/12)*12;
 const names={V:'vdc',AC:'sine',R:'resistor',C:'capacitor',LED:'led',SW:'switch',GND:'ground'};
 const prefixes={V:'V',AC:'VS',R:'R',C:'C',LED:'D',SW:'S',GND:'#PWR'};
 const key=p=>`${p.x},${p.y}`;
 const terminal=e=>e.type==='GND'?[{x:e.x,y:e.y-24}]:[{x:e.x-48,y:e.y},{x:e.x+48,y:e.y}];
 const within=(p,w)=>w.a.x===w.b.x ? p.x===w.a.x&&p.y>=Math.min(w.a.y,w.b.y)&&p.y<=Math.max(w.a.y,w.b.y) : w.a.y===w.b.y && p.y===w.a.y&&p.x>=Math.min(w.a.x,w.b.x)&&p.x<=Math.max(w.a.x,w.b.x);
 const interior=(p,w)=>within(p,w)&&key(p)!==key(w.a)&&key(p)!==key(w.b);
 const uid=()=>root.crypto?.randomUUID?.()||`local-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
 const uniqueJunctions=(js)=>{const at=new Set();for(const j of js){if(at.has(`${j.x},${j.y}`))throw Error('Duplicate junction');at.add(`${j.x},${j.y}`)}};
 function migrate(raw){
  if(!raw||!Array.isArray(raw.components)||!Array.isArray(raw.wires))throw Error('Not a Blaze CircuitLab project');
  if(raw.version!==undefined&&![1,2].includes(raw.version))throw Error('Unsupported Blaze project version');
  if(raw.components.length>200||raw.wires.length>700||(raw.junctions||[]).length>700)throw Error('Project size exceeds safe limits');
  const p=JSON.parse(JSON.stringify(raw)),legacy=p.version!==2;
  p.version=2;p.title=String(p.title||'Untitled Circuit').slice(0,80);p.junctions=p.junctions||[];
  const ids=new Set(),refs=new Set();
  for(const [i,c] of p.components.entries()){
   if(!names[c.type]||!Number.isFinite(c.x)||!Number.isFinite(c.y)||!Number.isFinite(c.value)||typeof c.id!=='string'||!c.id||refs.has(c.id))throw Error(`Invalid component at ${i}`);
   refs.add(c.id);c.uid=c.uid||`legacy-component-${i}-${c.id}`;
   if(ids.has(c.uid))throw Error('Duplicate component UUID');ids.add(c.uid);
  }
  for(const [i,w] of p.wires.entries()){
   if(!w.a||!w.b||![w.a.x,w.a.y,w.b.x,w.b.y].every(Number.isFinite))throw Error(`Invalid wire ${i}`);
   w.id=w.id||`legacy-wire-${i}`;if(ids.has(w.id))throw Error('Duplicate wire UUID');ids.add(w.id);
  }
  if(legacy){ // Original alpha joined a wire interior to pin/endpoints; preserve those connections explicitly.
   const pt=[...p.wires.flatMap(w=>[w.a,w.b]),...p.components.flatMap(terminal)];
   const existing=new Set(p.junctions.map(j=>key(j)));
   for(const pos of pt){if(p.wires.some(w=>interior(pos,w))&&!existing.has(key(pos))){p.junctions.push({id:`legacy-junction-${p.junctions.length}`,x:pos.x,y:pos.y});existing.add(key(pos));}}
  }
  for(const [i,j] of p.junctions.entries()){
   if(!Number.isFinite(j.x)||!Number.isFinite(j.y))throw Error('Invalid junction position');
   j.id=j.id||`legacy-junction-${i}`;if(ids.has(j.id))throw Error('Duplicate junction UUID');ids.add(j.id);
  }
  uniqueJunctions(p.junctions);
  return p;
 }
 const mm=n=>Math.round(n*SCALE*1e6)/1e6;
 const coord=p=>[mm(p.x),mm(p.y)];
 function toEngineering(project){
  const p=project.version===2?project:migrate(project);
  const count=new Map();
  const components=p.components.map(e=>{
   const type=names[e.type];if(!type)throw Error(`Unsupported part type: ${e.type}`);
   const prefix=prefixes[e.type];const existing=e.id.match(new RegExp(`^${e.type==='GND'?'G':e.type==='LED'?'D':e.type==='AC'?'AC':prefix}(\\d+)$`));
   const number=existing?.[1]||String((count.set(prefix,(count.get(prefix)||0)+1),count.get(prefix)));
   const ref=prefix+number;
   const c={id:e.uid,ref,type,at:coord(e.type==='GND'?{x:e.x,y:e.y-24}:e),rotation:0,value:e.type==='LED'?`LED (Vf~${e.value}V)`:e.type==='GND'?'GND':String(e.value)};
   return c;
  });
  return {schemaVersion:2,name:(p.title||'circuit').replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,64)||'circuit',components,
   wires:p.wires.map(w=>({id:w.id,from:coord(w.a),to:coord(w.b)})),
   junctions:p.junctions.map(j=>({id:j.id,at:coord(j)}))};
 }
 let lastKey='',lastResult=null;
 function build(project){
  const fingerprint=JSON.stringify([project.title,project.components.map(c=>[c.uid,c.id,c.type,c.x,c.y]),project.wires.map(w=>[w.id,w.a,w.b]),project.junctions]);
  if(fingerprint===lastKey&&lastResult)return lastResult;
  const model=toEngineering(project),topology=core.buildTopology(model);
  lastKey=fingerprint;lastResult={model,topology};return lastResult;
 }
 function connectivity(project){
  const {model,topology}=build(project),term={},byPin=new Map(topology.pins.map(p=>[p.componentId+':'+p.number,topology.byElement[p.id]]));
  const mapped=new Map(model.components.map(c=>[c.id,c]));
  for(const e of project.components){
   const c=mapped.get(e.uid),pins=core.SYMBOLS[c.type].pins;
   term[e.id]=pins.map(pin=>({at:core.globalPin(c,pin),net:byPin.get(c.id+':'+pin.number)}))
    .sort((a,b)=>a.at[0]===b.at[0]?a.at[1]-b.at[1]:a.at[0]-b.at[0]).map(x=>x.net);
  }
  let ground=null;for(const e of project.components)if(e.type==='GND'){ground=term[e.id][0];break;}
  const at=p=>{
   const w=project.wires.find(w=>key(w.a)===key(p)||key(w.b)===key(p));if(w)return topology.byElement['w:'+w.id];
   for(const e of project.components){const ix=terminal(e).findIndex(q=>key(q)===key(p));if(ix>=0)return term[e.id][ix];}
   return undefined;
  };
  return {term,at,ground,topology};
 }
 function exportProject(project){
  const {model,topology}=build(project);
  const result=ki.exportKiCad(model,topology);
  if(!ki.assertKiCadSexpr(result.schematic))throw Error('Invalid KiCad text');
  return result;
 }
 function junctionSite(project,p){return project.wires.some(w=>within(p,w))||project.components.some(e=>terminal(e).some(t=>key(t)===key(p)));}
 function nextReference(project,type){const pre=type==='LED'?'D':type==='GND'?'G':type==='SW'?'S':type==='AC'?'AC':type;let n=1;while(project.components.some(e=>e.id===pre+n))n++;return pre+n;}
 root.BlazeBridge={migrate,toEngineering,build,connectivity,exportProject,junctionSite,nextReference,uid,snap};
})(typeof window!=='undefined'?window:globalThis);
