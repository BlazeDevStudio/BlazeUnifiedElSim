/** Standalone, unintegrated Blaze CircuitLab topology candidate.
 * All coordinates are KiCad schematic millimeters (Y positive down).
 * Zero length, diagonal and overlapping wire segments are rejected.
 */
export const SYMBOLS = Object.freeze({
  resistor: {prefix: 'R', libId: 'BlazeCircuitLab:R', pins: [{number:'1', name:'1', at:[-5.08,0]},{number:'2',name:'2',at:[5.08,0]}]},
  led: {prefix:'D', libId:'BlazeCircuitLab:LED', pins:[{number:'2',name:'A',at:[-5.08,0]},{number:'1',name:'K',at:[5.08,0]}]},
  vdc: {prefix:'V', libId:'BlazeCircuitLab:VDC', pins:[{number:'2',name:'-',at:[-5.08,0]},{number:'1',name:'+',at:[5.08,0]}]},
  ground: {prefix:'#PWR', libId:'BlazeCircuitLab:GND', pins:[{number:'1',name:'GND',at:[0,0]}]},
  capacitor: {prefix:'C',libId:'BlazeCircuitLab:C',pins:[{number:'1',name:'1',at:[-5.08,0]},{number:'2',name:'2',at:[5.08,0]}]},
  sine: {prefix:'VS',libId:'BlazeCircuitLab:SINE',pins:[{number:'2',name:'-',at:[-5.08,0]},{number:'1',name:'+',at:[5.08,0]}]},
  switch: {prefix:'S',libId:'BlazeCircuitLab:SW',pins:[{number:'1',name:'1',at:[-5.08,0]},{number:'2',name:'2',at:[5.08,0]}]}
});
const PREC = 1e6;
const round = v => Math.round(v * PREC) / PREC;
export const posKey = p => `${round(p[0])},${round(p[1])}`;
const same = (a,b) => posKey(a) === posKey(b);
const between = (n,a,b) => n >= Math.min(a,b)-1e-8 && n <= Math.max(a,b)+1e-8;
const interior = (p,a,b) => onSegment(p,a,b) && !same(p,a) && !same(p,b);
const unique = arr => [...new Set(arr)];
const ordered = (a,b) => a < b ? [a,b] : [b,a];
export function onSegment(p,a,b) {
  if (a[0] === b[0]) return p[0] === a[0] && between(p[1],a[1],b[1]);
  if (a[1] === b[1]) return p[1] === a[1] && between(p[0],a[0],b[0]);
  return false;
}
export function globalPin(component,pin) {
  const r=(component.rotation||0)*Math.PI/180;
  const [x,y]=pin.at;
  return [round(component.at[0]+x*Math.cos(r)+y*Math.sin(r)),
          round(component.at[1]-x*Math.sin(r)+y*Math.cos(r))];
}
function assertPoint(p,label) {
  if (!Array.isArray(p)||p.length!==2||p.some(v=>!Number.isFinite(v)||Math.abs(v)>10000)) throw Error(`Invalid ${label}: coordinates must be finite within ±10000mm`);
  if (p.some(v=>Math.abs(round(v)-v)>1e-8)) throw Error(`${label} has unsupported sub-micrometer precision`);
}
function uniqueID(obj,type,ids) {
  if (!obj||typeof obj.id!=='string'||!obj.id.trim()||ids.has(obj.id)) throw Error(`Missing or duplicate ${type} id`);
  ids.add(obj.id);
}
export function validateProject(project) {
  if (!project || project.schemaVersion!==2 || typeof project.name!=='string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(project.name)) throw Error('Project schemaVersion must be 2 and name must be filename-safe');
  if (![project.components,project.wires,project.junctions].every(Array.isArray)) throw Error('components, wires, junctions arrays required');
  if (project.components.length>500 || project.wires.length>1000 || project.junctions.length>1000) throw Error('Project resource limit');
  const ids = new Set(), refs=new Set();
  for (const c of project.components) {
    uniqueID(c,'component',ids); assertPoint(c.at,`component ${c.id}`);
    const symbol=SYMBOLS[c.type];
    if (!symbol) throw Error(`Unsupported component: ${c.type}`);
    if (![0,90,180,270].includes(c.rotation??0)) throw Error(`Unsupported component rotation: ${c.id}`);
    if (typeof c.ref!=='string'||!new RegExp(`^${symbol.prefix.replace('#','\\#')}[0-9]+$`).test(c.ref)||refs.has(c.ref)) throw Error(`Invalid/duplicate reference: ${c.ref}`);
    refs.add(c.ref);
    if (typeof c.value!=='string'||!c.value||c.value.length>120) throw Error(`Invalid value: ${c.ref}`);
    if (c.footprint!==undefined && (typeof c.footprint!=='string'||c.footprint.length>160)) throw Error(`Invalid footprint: ${c.ref}`);
    if (c.footprint && ['ground','vdc'].includes(c.type)) throw Error(`Simulation-only source or ground cannot have invented footprint: ${c.ref}`);
  }
  for (const w of project.wires) {
    uniqueID(w,'wire',ids);assertPoint(w.from,`wire ${w.id}`);assertPoint(w.to,`wire ${w.id}`);
    if (same(w.from,w.to) || (w.from[0]!==w.to[0] && w.from[1]!==w.to[1])) throw Error(`Wire ${w.id} must be nonzero and orthogonal`);
  }
  for (const j of project.junctions) {uniqueID(j,'junction',ids);assertPoint(j.at,`junction ${j.id}`);}
  if (new Set(project.junctions.map(j=>posKey(j.at))).size!==project.junctions.length) throw Error('Duplicate junction position');
  return project;
}
class UnionFind {
  constructor(){this.parents=new Map();}
  add(x){if(!this.parents.has(x))this.parents.set(x,x);}
  find(x){let p=this.parents.get(x);if(p===undefined)throw Error('Unknown topology element '+x);if(p!==x){p=this.find(p);this.parents.set(x,p);}return p;}
  union(a,b){const [x,y]=ordered(this.find(a),this.find(b));this.parents.set(y,x);}
}
function cross(a,b){
  // nonparallel axis-aligned lines; returns intersection or null
  if ((a.from[0]===a.to[0]) === (b.from[0]===b.to[0])) return null;
  const v = a.from[0]===a.to[0]?a:b, h=v===a?b:a;
  const p=[v.from[0],h.from[1]];
  return onSegment(p,v.from,v.to)&&onSegment(p,h.from,h.to)?p:null;
}
function overlapping(a,b){
  if (a.from[0]===a.to[0] && b.from[0]===b.to[0] && a.from[0]===b.from[0]) return Math.min(Math.max(a.from[1],a.to[1]),Math.max(b.from[1],b.to[1])) > Math.max(Math.min(a.from[1],a.to[1]),Math.min(b.from[1],b.to[1]));
  if (a.from[1]===a.to[1] && b.from[1]===b.to[1] && a.from[1]===b.from[1]) return Math.min(Math.max(a.from[0],a.to[0]),Math.max(b.from[0],b.to[0])) > Math.max(Math.min(a.from[0],a.to[0]),Math.min(b.from[0],b.to[0]));
  return false;
}
export function buildTopology(project) {
  validateProject(project);
  const u=new UnionFind(), pins=[], junctions=new Set(project.junctions.map(j=>posKey(j.at)));
  for(const c of project.components){
    for(const pin of SYMBOLS[c.type].pins){const id=`p:${c.id}:${pin.number}`;u.add(id);pins.push({id, componentId:c.id, ref:c.ref, number:pin.number, at:globalPin(c,pin), type:c.type});}
  }
  for(const w of project.wires)u.add('w:'+w.id);
  // Coincident symbol pins are physically connected, as in KiCad.
  for(let i=0;i<pins.length;i++)for(let j=i+1;j<pins.length;j++)if(same(pins[i].at,pins[j].at))u.union(pins[i].id,pins[j].id);
  for(const w of project.wires){
    const wid='w:'+w.id;
    for(const pin of pins)if(onSegment(pin.at,w.from,w.to)){
      if(interior(pin.at,w.from,w.to)&&!junctions.has(posKey(pin.at))) throw Error(`Pin ${pin.ref}.${pin.number} touches interior of wire ${w.id} without junction`);
      u.union(wid,pin.id);
    }
  }
  for(let i=0;i<project.wires.length;i++)for(let j=i+1;j<project.wires.length;j++){
    const a=project.wires[i],b=project.wires[j],aid='w:'+a.id,bid='w:'+b.id;
    if(overlapping(a,b)) throw Error(`Overlapping wires ${a.id}/${b.id} must be canonicalized before simulation/export`);
    const cp=cross(a,b);
    if(cp){
      if(junctions.has(posKey(cp))){u.union(aid,bid);}
      else if (interior(cp,a.from,a.to) !== interior(cp,b.from,b.to)) throw Error(`Unmarked T intersection ${a.id}/${b.id} at ${posKey(cp)}`);
      else if(!interior(cp,a.from,a.to) && !interior(cp,b.from,b.to))u.union(aid,bid);
      // Interior/interior without a junction means deliberate disconnected crossing.
    }else for(const p of [a.from,a.to]) if(same(p,b.from)||same(p,b.to))u.union(aid,bid);
  }
  // Junctions actually touching more than one wire or pin connect those elements.
  for(const j of project.junctions){const touched=[];
    for(const w of project.wires)if(onSegment(j.at,w.from,w.to))touched.push('w:'+w.id);
    for(const p of pins)if(same(j.at,p.at))touched.push(p.id);
    if(!touched.length)throw Error('Orphan junction: '+j.id);
    for(const x of touched.slice(1))u.union(touched[0],x);
  }
  // All ground symbols correspond to one global GND net.
  const grounds=pins.filter(p=>p.type==='ground');for(const p of grounds.slice(1))u.union(grounds[0].id,p.id);
  const groups=new Map();for(const id of u.parents.keys()){
    const root=u.find(id);if(!groups.has(root))groups.set(root,[]);groups.get(root).push(id);
  }
  const entries=[...groups.values()].map(m=>m.sort()).sort((a,b)=>a[0].localeCompare(b[0]));
  const byElement={},nets=entries.map((members,i)=>{
    const name=members.some(m=>grounds.some(g=>g.id===m))?'GND':`N${String(i+1).padStart(3,'0')}`;
    for(const m of members)byElement[m]=name;
    return {name,members, pins:pins.filter(p=>members.includes(p.id)).map(p=>`${p.ref}.${p.number}`).sort(),wires:project.wires.filter(w=>members.includes('w:'+w.id)).map(w=>w.id).sort()};
  });
  // Reference names must be unique, including a GND group.
  const names = new Set();for(const net of nets){if(names.has(net.name)) throw Error('Duplicate net names');names.add(net.name);}
  return {pins,nets,byElement,junctions:[...junctions]};
}
export function splitWires(project){
  const junctions=project.junctions.map(j=>j.at);
  return project.wires.flatMap(w=>{
    const cut=[w.from,w.to,...junctions.filter(p=>interior(p,w.from,w.to))];
    const idx=(w.from[0]===w.to[0])?1:0;
    cut.sort((a,b)=>a[idx]-b[idx]);
    return cut.slice(1).map((p,i)=>({from:cut[i],to:p,sourceId:w.id,part:i}));
  });
}
