# Change log

## 0.2.0-dev (2026-10-27)

- Preserved user-uploaded alpha standalone HTML byte-for-byte.
- Added shared version-2 circuit graph and v1 migration with explicit legacy wire-interior junctions.
- Integrated topology into alpha MNA solver without changing its numerical stamping logic.
- Added Junction canvas tool, visible markers and keyboard shortcut J; improved crossing diagnostics.
- Stable IDs for new wires and added/duplicated components; retained existing component references.
- Added KiCad 9-targeted native schematic serializer for R, LED, V and GND with correct alpha polarities and no invented footprints.
- Added experimental browser download button and explicit Android bridge limitation.
- Regression tests for all three original demos, topology, migration and independent S-expression connectivity.
- Browser tests for both wide and narrow viewports, demos, KiCad export download, junction editing and undo.

### Remaining high-priority items

- Native KiCad open/ERC/netlist validation and correction of any resulting format problems.
- Import original Android wrapper and tests from complete alpha ZIP, add Storage Access Framework export.
- Build and actually test ARM64 Android APK.
- Add explicit rotation, normalized orthogonal wire editing, further supported KiCad symbols and virtual instruments.
