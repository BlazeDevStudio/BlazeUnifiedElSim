from playwright.sync_api import sync_playwright
from pathlib import Path
import json
BASE=Path(__file__).resolve().parents[1]
html=(BASE/'BlazeCircuitLab-v0.2-offline.html').read_text()
results=[]
def check(name,fn):
 try: fn();results.append(f'PASS {name}')
 except Exception as e: results.append(f'FAIL {name}: {e}');raise
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(1200,900),(390,844)]:
  page=browser.new_page(viewport={'width':width,'height':height},accept_downloads=True)
  errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
  page.set_content(html,wait_until='load');page.wait_for_timeout(250)
  check(f'load {width}x{height}',lambda: (not errors or (_ for _ in ()).throw(AssertionError(errors))))
  check(f'LED sim solves {width}x{height}',lambda: (page.evaluate('window.BlazeCircuitLab.getResult().ok') or (_ for _ in ()).throw(AssertionError(page.evaluate('window.BlazeCircuitLab.getResult().error')))))
  for id,name in [('demoRcBtn','RC'),('demoSwitchBtn','switch'),('demoLedBtn','LED')]:
   page.locator('#'+id).click();page.wait_for_timeout(70)
   check(f'{name} demo {width}x{height}',lambda: (page.evaluate('window.BlazeCircuitLab.getResult().ok') or (_ for _ in ()).throw(AssertionError(page.evaluate('window.BlazeCircuitLab.getResult().error')))))
  with page.expect_download(timeout=5000) as d:
   page.locator('#exportKiCadBtn').click()
  download=d.value
  assert download.suggested_filename.endswith('.kicad_sch')
  saved=BASE/'report'/('download-'+str(width)+'.kicad_sch');download.save_as(str(saved));assert saved.read_text().startswith('(kicad_sch')
  results.append(f'PASS KiCad button download {width}x{height}: {saved.name}')
  if width==1200:
   crossed={'version':2,'title':'Unconnected crossing','components':[],
     'wires':[{'id':'h','a':{'x':360,'y':240},'b':{'x':600,'y':240}}, {'id':'v','a':{'x':480,'y':120},'b':{'x':480,'y':360}}], 'junctions':[]}
   page.evaluate('(p)=>window.BlazeCircuitLab.loadProject(p)',crossed)
   assert page.evaluate("(function(){let t=window.BlazeBridge.connectivity(window.BlazeCircuitLab.getProject()).topology;return t.byElement['w:h']!==t.byElement['w:v']})()")
   page.locator('[data-tool=junction]').click()
   x,y=page.evaluate("(function(){const svg=document.querySelector('#schematic'), p=svg.createSVGPoint();p.x=480;p.y=240;const q=p.matrixTransform(svg.getScreenCTM());return [q.x,q.y]})()")
   page.mouse.click(x,y)
   assert page.evaluate('window.BlazeCircuitLab.getProject().junctions.length===1')
   assert page.evaluate("(function(){let t=window.BlazeBridge.connectivity(window.BlazeCircuitLab.getProject()).topology;return t.byElement['w:h']===t.byElement['w:v']})()")
   results.append('PASS UI explicit junction joins crossed wires')
   page.locator('#undoBtn').click()
   assert page.evaluate('window.BlazeCircuitLab.getProject().junctions.length===0')
   results.append('PASS UI undo removes explicit junction')
  assert not errors,errors
  page.close()
 browser.close()
(BASE/'report/browser-smoke.log').write_text('\n'.join(results)+'\n')
print('\n'.join(results))
