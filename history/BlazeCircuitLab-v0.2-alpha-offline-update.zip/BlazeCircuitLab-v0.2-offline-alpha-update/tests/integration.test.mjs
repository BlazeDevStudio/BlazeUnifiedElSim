import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const orig=fs.readFileSync(path.join(base,'BlazeCircuitLab-0.1.0-original-offline.html'),'utf8');
const html=fs.readFileSync(path.join(base,'BlazeCircuitLab-v0.2-offline.html'),'utf8');
function load(s){const ctx={TextEncoder,console,Math};ctx.globalThis=ctx;vm.createContext(ctx);
  for(const [,code] of s.matchAll(/<script>([\s\S]*?)<\/script>/g)){
    if(code.includes('const S=window.BlazeSim'))break;
    vm.runInContext(code,ctx,{timeout:2000});
  }return ctx;
}
const old=load(orig),app=load(html);const S=app.BlazeSim,B=app.BlazeBridge,T=app.BlazeCoreTopology,K=app.BlazeKiCad;
const solveSequence=(api,demo,upgrade)=>{let project=api[demos[demo]]();if(upgrade)project=B.migrate(project);let state=null;
  for(let i=0;i<15;i++){state=api.solve(project,state||{},.01,i*.01);if(!state.ok)throw Error(`${demo}: ${state.error}`);}return {project,state};};
const demos={led:'demoLED',rc:'demoRC',switch:'demoSW'};
for(const demo of Object.keys(demos))test(`Alpha ${demo} numerical behavior preserved`,()=>{
 const a=solveSequence(old.BlazeSim,demo,false),b=solveSequence(S,demo,true);
 for(const e of b.project.components.filter(x=>x.type!=='GND')){
  const x=a.state.currents[e.id],y=b.state.currents[e.id];assert.ok(Math.abs(x-y)<1e-7,`${demo} ${e.id}: old ${x} new ${y}`);
 }
 assert.equal(b.state.ok,true);
});
const wires=(p)=>({version:2,title:'Topology test',components:[],wires:p,junctions:[]});
const h={id:'h',a:{x:-48,y:0},b:{x:48,y:0}};
const v={id:'v',a:{x:0,y:-48},b:{x:0,y:48}};
test('Perpendicular crossing without junction is electrically disconnected',()=>{
 let topo=B.connectivity(wires([h,v])).topology;
 assert.notEqual(topo.byElement['w:h'],topo.byElement['w:v']);
});
test('Explicit junction joins crossed wires',()=>{
 let p=wires([h,v]);p.junctions=[{id:'j',x:0,y:0}];
 let topo=B.connectivity(p).topology;
 assert.equal(topo.byElement['w:h'],topo.byElement['w:v']);
});
test('Unmarked T junction does not silently connect and reports error',()=>{
 const p=wires([h,{id:'v',a:{x:0,y:0},b:{x:0,y:48}}]);
 assert.throws(()=>B.connectivity(p),/Unmarked T intersection/);
});
test('Marked T junction connects safely',()=>{
 let p=wires([h,{id:'v',a:{x:0,y:0},b:{x:0,y:48}}]);p.junctions=[{id:'j',x:0,y:0}];
 let t=B.connectivity(p).topology;assert.equal(t.byElement['w:h'],t.byElement['w:v']);
});
test('Legacy T junction migrates explicitly and maintains connectivity',()=>{
 let p={...wires([h,{id:'v',a:{x:0,y:0},b:{x:0,y:48}}]),version:1};
 const migrated=B.migrate(p);assert.equal(migrated.version,2);assert.equal(migrated.junctions.length,1);
 const t=B.connectivity(migrated).topology;assert.equal(t.byElement['w:h'],t.byElement['w:v']);
});
test('Legacy example ground interior touch becomes explicit junction',()=>{
 let p=B.migrate(S.demoLED());assert.deepEqual(JSON.parse(JSON.stringify(p.junctions.map(j=>[j.x,j.y]))),[[240,360]]);
});
test('Overlapping collinear wires are diagnosed',()=>{
 let p=wires([h,{id:'overlap',a:{x:0,y:0},b:{x:72,y:0}}]);assert.throws(()=>B.connectivity(p),/Overlapping wires/);
});
test('Stable IDs and ref designators survive v1 project migration twice',()=>{
 const original=S.demoLED();const p=B.migrate(original),p2=B.migrate(p);
 assert.deepEqual(JSON.parse(JSON.stringify(p)),JSON.parse(JSON.stringify(p2)));
 assert.equal(p.components[0].id,'V1');assert.equal(p.components[0].uid,'legacy-component-0-V1');
});
test('KiCad sample uses same authoritative topology as solver',()=>{
 const p=B.migrate(S.demoLED());const c=B.connectivity(p),x=B.exportProject(p);
 assert.deepEqual(JSON.parse(JSON.stringify(x.topology.nets)),JSON.parse(JSON.stringify(c.topology.nets)));
 assert.match(x.schematic,/\(kicad_sch/);assert.match(x.schematic,/\(version 20250114\)/);assert.ok(K.assertKiCadSexpr(x.schematic));
});
test('KiCad export is byte-for-byte deterministic',()=>{
 let p=B.migrate(S.demoLED());assert.equal(B.exportProject(p).schematic,B.exportProject(p).schematic);
});
test('KiCad diode anode and voltage positive terminals preserve original alpha direction',()=>{
 const p=B.migrate(S.demoLED()),model=B.toEngineering(p),byId=new Map(model.components.map(c=>[c.ref,c]));
 const pins=T.buildTopology(model).pins;
 const D=pins.filter(e=>e.ref==='D1').sort((a,b)=>a.at[0]-b.at[0]);
 assert.equal(D[0].number,'2');assert.equal(D[1].number,'1');
 const V=pins.filter(e=>e.ref==='V1').sort((a,b)=>a.at[0]-b.at[0]);
 assert.equal(V[0].number,'2');assert.equal(V[1].number,'1');
 assert.equal(byId.get('V1').value,'5');
});
test('Unsupported simulated AC/RC conversion is rejected, not mislabeled as KiCad',()=>{
 assert.throws(()=>B.exportProject(B.migrate(S.demoRC())),/not implemented/);
});
test('Invalid unmarked T prevents solve rather than reporting stale results',()=>{
 const p=wires([h,{id:'v',a:{x:0,y:0},b:{x:0,y:48}}]);let r=S.solve(p,{},.01,0);
 assert.equal(r.ok,false);assert.match(r.error,/Topology.*Unmarked T/);
});
test('No-ground circuit gives explicit error',()=>{
 const p=B.migrate(S.empty());const r=S.solve(p);assert.equal(r.ok,false);assert.match(r.error,/Add a GND/);
});
test('Version 2 local HTML is self-contained without external script/css URLs',()=>{
 assert.equal(/<script\s+[^>]*src=/.test(html),false);assert.equal(/<link\s+[^>]*href=/.test(html),false);
 assert.match(html,/id="exportKiCadBtn"/);assert.match(html,/data-tool="junction"/);
});

function parseSexpr(src){
  const tokens=src.match(/\s+|"(?:\\.|[^"\\])*"|[()]|[^()\s]+/g).filter(t=>!/\s/.test(t[0]));
  let offset=0;
  function parse(){
    if(tokens[offset++]!=='(')throw Error('Expected opening paren');
    const a=[];
    while(offset<tokens.length&&tokens[offset]!==')'){
      if(tokens[offset]==='(')a.push(parse());
      else {let raw=tokens[offset++];a.push(raw.startsWith('"')?JSON.parse(raw):raw);}
    }
    if(tokens[offset++]!==')')throw Error('Unexpected EOF');
    return a;
  }
  const r=parse();if(offset!==tokens.length)throw Error('Trailing S-expression tokens');return r;
}
const subs=(node,key)=>node.filter(x=>Array.isArray(x)&&x[0]===key);
const sub=(node,key)=>subs(node,key)[0];
const norm=n=>Math.round(Number(n)*1e6)/1e6;
const key=p=>p.map(norm).join(',');
const contains=(p,a,b)=>{
  if(a[0]===b[0]&&p[0]===a[0])return p[1]>=Math.min(a[1],b[1])&&p[1]<=Math.max(a[1],b[1]);
  if(a[1]===b[1]&&p[1]===a[1])return p[0]>=Math.min(a[0],b[0])&&p[0]<=Math.max(a[0],b[0]);
  return false;
};
function nativeGraphFromSexpr(src){
  const root=parseSexpr(src);assert.equal(root[0],'kicad_sch');
  const defs=new Map();
  for(const d of subs(sub(root,'lib_symbols'),'symbol')){
    const pins=subs(d,'symbol').flatMap(s=>subs(s,'pin')).map(p=>({at:sub(p,'at').slice(1,3).map(Number),number:sub(p,'number')[1]}));
    defs.set(d[1],pins);
  }
  const pins=[];
  for(const s of subs(root,'symbol')){
    const libId=sub(s,'lib_id')[1],pos=sub(s,'at').slice(1).map(Number);
    const angle=pos[2]*Math.PI/180;
    const ref=subs(s,'property').find(p=>p[1]==='Reference')?.[2];
    assert.ok(ref&&defs.has(libId));
    for(const p of defs.get(libId)){
      const [x,y]=p.at;
      const at=[norm(pos[0]+x*Math.cos(angle)+y*Math.sin(angle)), norm(pos[1]-x*Math.sin(angle)+y*Math.cos(angle))];
      pins.push({at,ref,num:p.number,ground:libId.endsWith(':GND')});
    }
  }
  const wires=subs(root,'wire').map(w=>subs(sub(w,'pts'),'xy').map(x=>x.slice(1,3).map(Number)));
  const junctions=subs(root,'junction').map(j=>sub(j,'at').slice(1,3).map(Number));
  const parent=Array.from({length:pins.length+wires.length},(_,i)=>i);
  function find(x){while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;}
  function union(a,b){a=find(a);b=find(b);if(a!==b)parent[b]=a;}
  for(let i=0;i<pins.length;i++)for(let j=i+1;j<pins.length;j++){
    if(key(pins[i].at)===key(pins[j].at)||(pins[i].ground&&pins[j].ground))union(i,j);
  }
  for(let i=0;i<pins.length;i++)for(let j=0;j<wires.length;j++){
    if(contains(pins[i].at,...wires[j]))union(i,pins.length+j);
  }
  for(let i=0;i<wires.length;i++)for(let j=i+1;j<wires.length;j++){
    if(wires[i].some(a=>wires[j].some(b=>key(a)===key(b))) || junctions.some(p=>contains(p,...wires[i])&&contains(p,...wires[j])))union(pins.length+i,pins.length+j);
  }
  const groups=new Map();for(let i=0;i<pins.length;i++){
    const r=find(i);if(!groups.has(r))groups.set(r,[]);groups.get(r).push(pins[i].ref+'.'+pins[i].num);
  }
  return [...groups.values()].map(a=>a.sort().join('|')).sort();
}

test('Independent S-expression parser reconstructs exported electrical pin nets',()=>{
 const p=B.migrate(S.demoLED()), eng=B.toEngineering(p), out=B.exportProject(p);
 const expected=T.buildTopology(eng).nets.map(n=>n.pins.join('|')).filter(Boolean).sort();
 assert.deepEqual(JSON.parse(JSON.stringify(nativeGraphFromSexpr(out.schematic))),JSON.parse(JSON.stringify(expected)));
});
test('Independent S-expression reader preserves source wire-net counts',()=>{
 const p=wires([h,v]), exp=B.exportProject(p).schematic;
 assert.ok(K.assertKiCadSexpr(exp));
 const parsed=parseSexpr(exp);assert.equal(subs(parsed,'wire').length,2);assert.equal(subs(parsed,'junction').length,0);
});
test('Native KiCad serializer does not fabricate footprints for a simulation-only source',()=>{
 const x=B.exportProject(B.migrate(S.demoLED()));assert.match(x.schematic,/\(on_board no\)/);
 assert.ok(x.warnings.some(w=>w.includes('V1: simulation/power object')));
 assert.ok(x.warnings.some(w=>w.includes('R1: no physical footprint')));
});
