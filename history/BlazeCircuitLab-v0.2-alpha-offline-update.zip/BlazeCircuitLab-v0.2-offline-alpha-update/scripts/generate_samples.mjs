import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';
const base=path.resolve(import.meta.dirname,'..');
const html=fs.readFileSync(path.join(base,'BlazeCircuitLab-v0.2-offline.html'),'utf8');
const env={TextEncoder,Math,console};env.globalThis=env;vm.createContext(env);
for(const [,code] of html.matchAll(/<script>([\s\S]*?)<\/script>/g)){
 if(code.includes('const S=window.BlazeSim'))break;
 vm.runInContext(code,env,{timeout:3000});
}
const original=env.BlazeSim.demoLED(),migrated=env.BlazeBridge.migrate(original),exp=env.BlazeBridge.exportProject(migrated);
const dir=path.join(base,'samples/led-current-limiter');fs.mkdirSync(dir,{recursive:true});
const out=(name,data)=>fs.writeFileSync(path.join(dir,name),data);
out('legacy-alpha-v1.json',JSON.stringify(original,null,2));
out('migrated-v2.json',JSON.stringify(migrated,null,2));
out('led-current-limiter.kicad_sch',exp.schematic);
out('BlazeCircuitLab.kicad_sym',exp.library);
out('sym-lib-table',exp.table);
out('warnings.json',JSON.stringify(exp.warnings,null,2));
out('expected-netgraph.json',JSON.stringify(exp.topology.nets,null,2));
console.log('Generated sample with',exp.topology.nets.length,'nets,',migrated.junctions.length,'junctions,',exp.uuidCount,'UUIDs');
