from pathlib import Path
import re
base=Path(__file__).resolve().parents[1]
orig=(base/'BlazeCircuitLab-0.1.0-original-offline.html').read_text()
topo=(base/'src/topology.mjs').read_text()
kicad=(base/'src/kicad.mjs').read_text()
bridge=(base/'src/alpha-bridge.js').read_text()
# Bundle genuine shared source into offline HTML without network imports; retains separate modules for Node test.
topo=re.sub(r'\bexport (?=(?:const|function|class)\b)','',topo)
topo='(function(root){\n'+topo+'\nroot.BlazeCoreTopology={SYMBOLS,posKey,onSegment,globalPin,validateProject,buildTopology,splitWires};\n})(typeof window!=="undefined"?window:globalThis);'
kicad=re.sub(r'^import .*?\n','',kicad,flags=re.M)
kicad=re.sub(r'\bexport (?=(?:const|function|class)\b)','',kicad)
kicad='(function(root){\nconst {SYMBOLS,buildTopology,splitWires,globalPin,validateProject}=root.BlazeCoreTopology;\n'+kicad+'\nroot.BlazeKiCad={exportKiCad,assertKiCadSexpr};\n})(typeof window!=="undefined"?window:globalThis);'
pre='\n<script>\n'+topo+'\n</script>\n<script>\n'+kicad+'\n</script>\n<script>\n'+bridge+'\n</script>\n'
s=orig.replace('</style></head>','</style></head>'+pre,1)
# replace original connectivity with the authoritative common model
s,n=re.subn(r'function connectivity\(circuit\)\{.*?\n\}\nfunction linearSolve',"function connectivity(circuit){return root.BlazeBridge.connectivity(circuit)}\nfunction linearSolve",s,count=1,flags=re.S)
assert n==1,'solver connectivity replacement failed'
s,n=re.subn(r'[ ]*const \{term,at,ground\}=connectivity\(circuit\);',"  let connection;\n  try{ connection=connectivity(circuit); }catch(e){return {ok:false,error:'Topology: '+e.message,volts:{},currents:{},term:{}};}\n  const {term,at,ground}=connection;",s,count=1)
assert n==1,'solver hook replacement failed'
s=s.replace("let project=S.demoLED()","let project=window.BlazeBridge.migrate(S.demoLED())",1)
# migrate old projects to v2, preserve all legacy component values and wires
needle="return {version:1,title:raw.title.slice(0,80),components:raw.components.map(e=>({...e,x:S.snap(e.x),y:S.snap(e.y),value:Math.max(0,Math.min(1e9,e.value)),freq:Math.max(.001,Math.min(10000,Number(e.freq)||1)),closed:Boolean(e.closed)})),wires:raw.wires.map(w=>({a:{x:S.snap(w.a.x),y:S.snap(w.a.y)},b:{x:S.snap(w.b.x),y:S.snap(w.b.y)}}))}"
assert needle in s
replacement="return window.BlazeBridge.migrate({version:raw.version??1,title:raw.title.slice(0,80),components:raw.components.map(e=>({...e,x:S.snap(e.x),y:S.snap(e.y),value:Math.max(0,Math.min(1e9,e.value)),freq:Math.max(.001,Math.min(10000,Number(e.freq)||1)),closed:Boolean(e.closed)})),wires:raw.wires.map(w=>({...w,a:{x:S.snap(w.a.x),y:S.snap(w.a.y)},b:{x:S.snap(w.b.x),y:S.snap(w.b.y)}})),junctions:(raw.junctions||[]).map(j=>({...j,x:S.snap(j.x),y:S.snap(j.y)}))})"
s=s.replace(needle,replacement,1)
# blank new project always upgraded
s=s.replace("$('newBtn').onclick=()=>setProject(S.empty())","$('newBtn').onclick=()=>setProject(S.empty())",1)
# proper stable identities for components and wires
needle="const next=id+(++seq);project.components.push(S.add(tool,next,p.x,p.y));selected=next;"
assert needle in s
s=s.replace(needle,"const next=window.BlazeBridge.nextReference(project,tool);project.components.push(S.add(tool,next,p.x,p.y,{uid:window.BlazeBridge.uid()}));selected=next;",1)
s=s.replace("project.components.push({...e,id,x:e.x+0,y:e.y+108});","project.components.push({...e,id:window.BlazeBridge.nextReference(project,e.type),uid:window.BlazeBridge.uid(),x:e.x,y:e.y+108});",1)
s=s.replace("selected=id;changed()}\n function toggleSW", "selected=project.components[project.components.length-1].id;changed()}\n function toggleSW",1)
# inspect transform and ensure duplicate updates actual select
s=s.replace("selected=id;changed()}\nfunction toggleSW", "selected=project.components[project.components.length-1].id;changed()}\nfunction toggleSW",1)
# wires, default orthogonal routing, stable IDs
s=s.replace("project.wires.push({a:{...a},b:intermediate},{a:intermediate,b:{...b}})","project.wires.push({id:window.BlazeBridge.uid(),a:{...a},b:intermediate},{id:window.BlazeBridge.uid(),a:intermediate,b:{...b}})",1)
s=s.replace("project.wires.push({a:{...a},b:{...b}})","project.wires.push({id:window.BlazeBridge.uid(),a:{...a},b:{...b}})",1)
# UI tool for intentional joints
s=s.replace('<button class="tool" data-tool="wire"><span class="toolicon">⌁</span><span>Wire</span><kbd>W</kbd></button>','<button class="tool" data-tool="wire"><span class="toolicon">⌁</span><span>Wire</span><kbd>W</kbd></button>\n     <button class="tool" data-tool="junction"><span class="toolicon">●</span><span>Junction</span><kbd>J</kbd></button>',1)
s=s.replace("t==='pan'?'Drag the canvas to move the view'", "t==='junction'?'Tap a wire connection or crossing to make an explicit junction':t==='pan'?'Drag the canvas to move the view'",1)
needle="if(tool==='wire'){const pt=svgHitTerminal(ev,p);"
assert needle in s
s=s.replace(needle,"if(tool==='junction'){if(!window.BlazeBridge.junctionSite(project,p)){toast('Place junction on an existing wire or terminal');return}if(project.junctions.some(j=>j.x===p.x&&j.y===p.y)){toast('Junction already exists');return}snapshot();project.junctions.push({id:window.BlazeBridge.uid(),x:p.x,y:p.y});changed();return}if(tool==='wire'){const pt=svgHitTerminal(ev,p);",1)
s=s.replace("if(ev.key.toLowerCase()==='w')setTool('wire');","if(ev.key.toLowerCase()==='w')setTool('wire');if(ev.key.toLowerCase()==='j')setTool('junction');",1)
# Wire endpoints not automatically junction dots; only true joins have filled black circles
s=s.replace('"/><circle cx="${w.a.x}" cy="${w.a.y}" r="3" fill="${color}"/><circle cx="${w.b.x}" cy="${w.b.y}" r="3" fill="${color}"/>','"/>',1)
s=s.replace("  if(hintStart){if(hoverPoint)","  for(const j of project.junctions||[])lines+=`<circle cx=\"${j.x}\" cy=\"${j.y}\" r=\"5\" fill=\"#58e6ca\" stroke=\"#08111b\" stroke-width=\"1.3\"/>`;\n  if(hintStart){if(hoverPoint)",1)
# Export button and usable offline browser download
s=s.replace('<button id="saveBtn">↓ Export JSON</button><button id="importBtn">↑ Import</button>','<button id="saveBtn">↓ Export JSON</button><button id="importBtn">↑ Import</button><button id="exportKiCadBtn" title="Experimental native KiCad schematic. Open/ERC/netlist validation remains required.">↓ KiCad .sch (experimental)</button>',1)
s=s.replace('.file-actions{display:grid;grid-template-columns:1fr 1fr;', '.file-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));',1)
loc='function drawScope(){'
assert loc in s
s=s.replace(loc,'''function exportKiCadFile(){try{
 const out=window.BlazeBridge.exportProject(project);
 if(window.BlazeAndroid){toast('KiCad export unavailable in this unverified Android WebView wrapper');return}
 const name=(project.title.toLowerCase().replace(/[^a-z0-9]+/g,'-')||'circuit')+'.kicad_sch';
 const link=document.createElement('a');link.href=URL.createObjectURL(new Blob([out.schematic],{type:'text/plain;charset=utf-8'}));link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(link.href),10000);
 toast('Experimental KiCad schematic exported. Native KiCad verification required.');
 }catch(err){toast('KiCad export blocked: '+err.message)}
}
''' + loc,1)
s=s.replace("$('saveBtn').onclick=exportFile;", "$('saveBtn').onclick=exportFile;$('exportKiCadBtn').onclick=exportKiCadFile;",1)
# Preserve the original v1 saved JSON before the first v2 write, independent from the in-memory migration.
s=s.replace("if(saved)project=safeProject(JSON.parse(saved))", "if(saved){const raw=JSON.parse(saved);if(raw.version!==2){try{if(!localStorage.getItem('blaze-circuitlab-project-v1-backup'))localStorage.setItem('blaze-circuitlab-project-v1-backup',saved)}catch(backupError){$('warning').textContent='Legacy backup unavailable: export JSON before editing';}}project=safeProject(raw)}",1)

# Zero solver state after importing/adding topology; no split-brain state
# assign latest alpha label accurately
s=s.replace('OFFLINE CIRCUIT STUDIO · ALPHA 0.1','OFFLINE CIRCUIT STUDIO · v0.2 DEVELOPMENT',1)
s=s.replace('Basic MNA engine · Resistors / capacitors / voltage sources / switches / simplified LEDs','Educational MNA · Explicit junctions · KiCad export experimental; not native verified',1)
out=base/'BlazeCircuitLab-v0.2-offline.html';out.write_text(s)
print('Built',out,'size',out.stat().st_size)
