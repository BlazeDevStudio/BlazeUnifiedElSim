# Blaze CircuitLab — 0.2.0 Development Update

**Integrated with the user-supplied `BlazeCircuitLab-offline.html`; not a separately restarted application.**

## Important source limitation

The supplied file was one fully self-contained HTML document, not the complete `BlazeCircuitLab-0.1.0-alpha.zip`. The original HTML is preserved verbatim as `BlazeCircuitLab-0.1.0-original-offline.html`. It contains the alpha MNA solver, editing UI and three demos. The Android wrapper directory, separate original test suite, Gradle project and original multi-file architecture were not supplied; this package does not claim they have been inspected or modified. **No APK is included.**

## What is implemented in the standalone HTML

- Shared electrical topology graph (`src/topology.mjs`) for both the real alpha solver and schematic serializer.
- Two distinct intersecting wires remain disconnected at an unmarked interior/interior crossing.
- Explicit Junction tool (toolbar/`J`) makes a crossing or T connection. Unmarked T junctions and overlapping collinear wires fail with a diagnostic rather than silently joining nets.
- Legacy `version:1` projects migrate in memory to `version:2`, adding explicit junctions where alpha historically joined a terminal or wire endpoint to the interior of another wire. Component refs, values, wire coordinates and simulation behavior are retained; migrated entities have stable IDs.
- Existing localStorage legacy project JSON is backed up to `blaze-circuitlab-project-v1-backup` before replacement with version 2 where storage permits. It is important to export a JSON backup before destructive edits if a device disallows localStorage.
- Original LED, RC and switch demos remain available and their numerical outcomes match the exact user-uploaded solver in comparison tests.
- Browser-side **experimental** `.kicad_sch` export supports resistors, LEDs, ideal DC voltage sources and GND, using built-in KiCad-targeted symbol definitions. Exporter preserves the alpha's source/LED terminal polarity. A physical footprint is never invented. This is schematic export only, not PCB output.
- When the original Android WebView bridge is detected, the new KiCad export is reported unsupported rather than pretending Android file saving works. Native Android Storage Access Framework support remains pending.

## What is **not** verified or implemented

- Native KiCad app open/ERC/netlist export: **NOT TESTED**, `kicad-cli` unavailable in this environment.
- KiCad symbol/footprint resolver compatibility beyond independent S-expression checking: **NOT VALIDATED**.
- Android APK/build/emulator/physical phone: **NOT TESTED**, original Android project and Gradle build are missing.
- PCB design, ESP/Arduino CPU emulation, advanced SPICE, arbitrary file formats: **NOT IMPLEMENTED**.
- KiCad export for `AC`, `C`, `SW` simulated types: **EXPLICITLY BLOCKED**, not fake symbols.
- Wiring diagonal segments and overlapping collinear wires: **NOT SUPPORTED** by the new topology engine; shows a clear error when encountered rather than guessing.
- Full import/export of KiCad circuits, KiCad project ZIP, PCB format: **NOT IMPLEMENTED**.
- Midrange phone performance, background solver and crash recovery: **NOT BENCHMARKED**.

## How to use

Open `BlazeCircuitLab-v0.2-offline.html` in a capable browser locally. No external JS/CSS resources or network access are needed. Load LED/RC/Switch examples as before. Tap Junction (or keyboard J), then tap an existing wire intersection to connect it. Use `↓ KiCad .sch (experimental)` from the project panel for supported circuits. Load the resulting `.kicad_sch` in KiCad 9 and check actual netlist/ERC before relying on it.

**The KiCad schematic contains embedded custom symbol definitions** and the sample also supplies a `.kicad_sym` library and `sym-lib-table` as supplementary artifacts. KiCad physical PCB and fabrication functionality are not available.

For KiCad 9 native confirmation, run from `samples/led-current-limiter` on a machine with KiCad installed:

```sh
kicad-cli sch export netlist -o led-current-limiter.net led-current-limiter.kicad_sch
kicad-cli sch erc -o led-current-limiter-erc.txt led-current-limiter.kicad_sch
```

Compare the generated native netlist to `expected-netgraph.json` (3 pin-connected nets). In particular, `V1.1` (right, positive) joins `R1.1`; `D1.2` (left, anode) joins `R1.2`; `V1.2`, `D1.1` and `#PWR1.1` join ground. Alpha `G1` becomes KiCad's reserved power designation `#PWR1` but the native source component ID remains `G1`.

## Building and testing

The HTML bundle is reproducibly assembled from the retained original and new source modules. Requires Python 3 and Node.js 18+:

```sh
python3 scripts/build.py
node scripts/generate_samples.mjs
npm test
```

Chromium browser UI smoke tests additionally require Python `playwright` and local Chromium executable `/usr/bin/chromium` (modify the test path if needed):

```sh
python3 tests/browser_smoke.py
```

**Recorded execution:** 21/21 Node automated tests passed; 14/14 browser smoke checks passed on 1200×900 and 390×844; original three example circuit calculations preserved against the uploaded HTML. The S-expression reader independently reconstructed exported pin nets; this is not native KiCad validation.

## Engineering warnings

The original solver remains educational MNA with simplified LED, finite-resistance switch and small numerical gmin; it is not a validated SPICE engine and cannot certify electrical or physical safety. If a graph is ambiguous, the revised solver emits an error rather than reporting fabricated results. If exporting to KiCad for design, independently verify component ratings, footprints, pin numbering and electrical nets.

## Upstream file format references

- https://dev-docs.kicad.org/en/file-formats/sexpr-schematic/
- https://docs.kicad.org/9.0/en/cli/cli.html

All new code is project-specific; this archive does not bundle proprietary KiCad or EveryCircuit application code.
