import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {exportKiCad} from '../src/kicad.mjs';
import {buildTopology} from '../src/topology.mjs';
// Separate, intentionally minimal KiCad S-expression reader for exported connectivity parity.
// This is NOT a KiCad native parser/validator.
function parseSexpr(src){
  const tokens=src.match(/\s+|"(?:\\.|[^"\\])*"|[()]|[^()\s]+/g).filter(t=>!/\s/.test(t[0]));
  let offset=0;
  function parse(){
    if(tokens[offset++]!=='(')throw Error('Expected opening paren');
    const a=[];
    while(offset<tokens.length&&tokens[offset]!==')'){
      if(tokens[offset]==='(')a.push(parse());
      else {let raw=tokens[offset++];a.push(raw.startsWith('"')?JSON.parse(raw):raw);}
    }
    if(tokens[offset++]!==')')throw Error('Unexpected EOF');
    return a;
  }
  const r=parse();if(offset!==tokens.length)throw Error('Trailing S-expression tokens');return r;
}
const subs=(node,key)=>node.filter(x=>Array.isArray(x)&&x[0]===key);
const sub=(node,key)=>subs(node,key)[0];
const norm=n=>Math.round(Number(n)*1e6)/1e6;
const key=p=>p.map(norm).join(',');
const contains=(p,a,b)=>{
  if(a[0]===b[0]&&p[0]===a[0])return p[1]>=Math.min(a[1],b[1])&&p[1]<=Math.max(a[1],b[1]);
  if(a[1]===b[1]&&p[1]===a[1])return p[0]>=Math.min(a[0],b[0])&&p[0]<=Math.max(a[0],b[0]);
  return false;
};
function nativeGraphFromSexpr(src){
  const root=parseSexpr(src);assert.equal(root[0],'kicad_sch');
  const defs=new Map();
  for(const d of subs(sub(root,'lib_symbols'),'symbol')){
    const pins=subs(d,'symbol').flatMap(s=>subs(s,'pin')).map(p=>({at:sub(p,'at').slice(1,3).map(Number),number:sub(p,'number')[1]}));
    defs.set(d[1],pins);
  }
  const pins=[];
  for(const s of subs(root,'symbol')){
    const libId=sub(s,'lib_id')[1],pos=sub(s,'at').slice(1).map(Number);
    const angle=pos[2]*Math.PI/180;
    const ref=subs(s,'property').find(p=>p[1]==='Reference')?.[2];
    assert.ok(ref&&defs.has(libId));
    for(const p of defs.get(libId)){
      const [x,y]=p.at;
      const at=[norm(pos[0]+x*Math.cos(angle)+y*Math.sin(angle)), norm(pos[1]-x*Math.sin(angle)+y*Math.cos(angle))];
      pins.push({at,ref,num:p.number,ground:libId.endsWith(':GND')});
    }
  }
  const wires=subs(root,'wire').map(w=>subs(sub(w,'pts'),'xy').map(x=>x.slice(1,3).map(Number)));
  const junctions=subs(root,'junction').map(j=>sub(j,'at').slice(1,3).map(Number));
  const parent=Array.from({length:pins.length+wires.length},(_,i)=>i);
  function find(x){while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;}
  function union(a,b){a=find(a);b=find(b);if(a!==b)parent[b]=a;}
  for(let i=0;i<pins.length;i++)for(let j=i+1;j<pins.length;j++){
    if(key(pins[i].at)===key(pins[j].at)||(pins[i].ground&&pins[j].ground))union(i,j);
  }
  for(let i=0;i<pins.length;i++)for(let j=0;j<wires.length;j++){
    if(contains(pins[i].at,...wires[j]))union(i,pins.length+j);
  }
  for(let i=0;i<wires.length;i++)for(let j=i+1;j<wires.length;j++){
    if(wires[i].some(a=>wires[j].some(b=>key(a)===key(b))) || junctions.some(p=>contains(p,...wires[i])&&contains(p,...wires[j])))union(pins.length+i,pins.length+j);
  }
  const groups=new Map();for(let i=0;i<pins.length;i++){
    const r=find(i);if(!groups.has(r))groups.set(r,[]);groups.get(r).push(pins[i].ref+'.'+pins[i].num);
  }
  return [...groups.values()].map(a=>a.sort().join('|')).sort();
}
const expected=p=>buildTopology(p).nets.map(n=>n.pins.join('|')).filter(Boolean).sort();
const sample=()=>JSON.parse(readFileSync(new URL('../samples/series-led.project.json',import.meta.url)));
test('independent reader reconstructs all sample electrical nets from S-expression',()=>{
  const p=sample();assert.deepEqual(nativeGraphFromSexpr(exportKiCad(p).schematic),expected(p));
});
test('independent reader preserves disconnected crossing topology',()=>{
  const p={schemaVersion:2,name:'crossing',components:[],wires:[{id:'a',from:[0,10],to:[20,10]},{id:'b',from:[10,0],to:[10,20]}],junctions:[]};
  assert.deepEqual(nativeGraphFromSexpr(exportKiCad(p).schematic),[]);
  // no pins in sample; wire net counts instead checked in topology regression.
});
test('independent reader confirms rotations and two net membership',()=>{
  const p={schemaVersion:2,name:'rotated',components:[
    {id:'a',type:'resistor',ref:'R1',value:'100',at:[20,20],rotation:90},
    {id:'b',type:'resistor',ref:'R2',value:'1k',at:[40,20],rotation:90}
  ],wires:[{id:'w',from:[20,14.92],to:[40,14.92]}],junctions:[]};
  assert.deepEqual(nativeGraphFromSexpr(exportKiCad(p).schematic),expected(p));
});
