import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildTopology,globalPin,SYMBOLS,splitWires} from '../src/topology.mjs';
import {exportKiCad,assertKiCadSexpr} from '../src/kicad.mjs';

const empty=()=>({schemaVersion:2,name:'test',components:[],wires:[],junctions:[]});
const wire=(id,from,to)=>({id,from,to});
const j=(id,at)=>({id,at});
const fixture=()=>JSON.parse(readFileSync(new URL('../samples/series-led.project.json',import.meta.url)));
const pinPairs=topo=>topo.nets.map(n=>n.pins.join('|')).filter(Boolean).sort();

test('series LED circuit has exactly three electrical nets',()=>{
  assert.deepEqual(pinPairs(buildTopology(fixture())),['#PWR1.1|R1.1|V1.2','D1.1|R1.2','D1.2|V1.1']);
});
test('perpendicular crossing with no explicit junction is disconnected',()=>{
  const p=empty();p.wires=[wire('a',[0,10],[20,10]),wire('b',[10,0],[10,20])];
  assert.equal(buildTopology(p).nets.length,2);
});
test('explicit junction joins crossing and exporter splits wire segments',()=>{
  const p=empty();p.wires=[wire('a',[0,10],[20,10]),wire('b',[10,0],[10,20])];p.junctions=[j('ja',[10,10])];
  assert.equal(buildTopology(p).nets.length,1);
  assert.equal(splitWires(p).length,4);
});
test('shared endpoints join without extra dots',()=>{
  const p=empty();p.wires=[wire('a',[0,0],[10,0]),wire('b',[10,0],[10,10])];
  assert.equal(buildTopology(p).nets.length,1);
});
test('ambiguous T endpoint touching a wire interior is rejected',()=>{
  const p=empty();p.wires=[wire('a',[0,10],[20,10]),wire('b',[10,0],[10,10])];
  assert.throws(()=>buildTopology(p),/Unmarked T intersection/);
});
test('explicit T junction is connected',()=>{
  const p=empty();p.wires=[wire('a',[0,10],[20,10]),wire('b',[10,0],[10,10])];p.junctions=[j('ja',[10,10])];
  assert.equal(buildTopology(p).nets.length,1);
  assert.equal(splitWires(p).length,3);
});
test('collinear wire overlaps rejected rather than silently changing net',()=>{
  const p=empty();p.wires=[wire('a',[0,0],[20,0]),wire('b',[10,0],[30,0])];
  assert.throws(()=>buildTopology(p),/Overlapping wires/);
});
test('pin on wire interior requires explicit junction',()=>{
  const p=empty();p.components=[{id:'r',ref:'R1',type:'resistor',value:'1k',at:[10,0],rotation:0}];p.wires=[wire('a',[0,0],[20,0])];
  assert.throws(()=>buildTopology(p),/Pin R1/);
});
test('rotation 90 maps resistor left terminal to screen bottom',()=>{
  const c={at:[20,20],rotation:90};
  assert.deepEqual(globalPin(c,SYMBOLS.resistor.pins[0]),[20,25.08]);
  assert.deepEqual(globalPin(c,SYMBOLS.resistor.pins[1]),[20,14.92]);
});
test('no diagonal or zero length wires',()=>{
  const p=empty();p.wires=[wire('a',[0,0],[5,5])];assert.throws(()=>buildTopology(p),/orthogonal/);
  p.wires=[wire('a',[0,0],[0,0])];assert.throws(()=>buildTopology(p),/nonzero/);
});
test('duplicate identifiers and references fail closed',()=>{
  const p=fixture();p.wires[1].id=p.wires[0].id;assert.throws(()=>buildTopology(p),/duplicate/);
  p.wires[1].id='w2';p.components[1].ref='V1';assert.throws(()=>buildTopology(p),/Invalid\/duplicate/);
});
test('unsupported simulated component rejected rather than cosmetically serialized',()=>{
  const p=fixture();p.components.push({id:'mosfet',ref:'Q1',type:'mosfet',at:[10,50],value:'2N7000'});
  assert.throws(()=>exportKiCad(p),/Unsupported component/);
});
test('KiCad serializes deterministic file and does not alter source project',()=>{
  const p=fixture(),copy=structuredClone(p),a=exportKiCad(p),b=exportKiCad(p);
  assert.equal(a.schematic,b.schematic);assert.deepEqual(p,copy);
  assert.ok(assertKiCadSexpr(a.schematic));
  assert.match(a.schematic,/\(generator "blaze_circuitlab"\)/);
  assert.match(a.schematic,/\(lib_symbols/);
  assert.match(a.schematic,/\(instances \(project "series-led"/);
  assert.match(a.schematic,/\(junction \(at 25\.4 25\.4\)/);
  assert.deepEqual(pinPairs(a.topology),pinPairs(buildTopology(p)));
});
test('KiCad serializes correct number of unique UUIDs',()=>{
  const r=exportKiCad(fixture());
  const ids=[...r.schematic.matchAll(/\(uuid "([a-f0-9-]{36})"\)/g)].map(x=>x[1]);
  assert.equal(new Set(ids).size,ids.length);
  assert.equal(ids.length,r.uuidCount);
  assert.ok(ids.every(s=>/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-a[0-9a-f]{3}-[0-9a-f]{12}$/.test(s)));
});
test('exporter warns about missing physical footprints and simulation-only source',()=>{
  const r=exportKiCad(fixture());assert.match(r.warnings.join(';'),/R1: no physical footprint/);assert.match(r.warnings.join(';'),/V1: simulation/);
});
test('unsafe input and escape are handled',()=>{
  const p=fixture();p.components[1].value='330 "Ohm"\\test';
  assert.match(exportKiCad(p).schematic,/330 \\"Ohm\\"\\\\test/);
  p.components[1].value='330\u0000Ohm';assert.throws(()=>exportKiCad(p),/Invalid KiCad text/);
});
test('export does not connect a wire crossover without a dot',()=>{
  const p=empty();p.wires=[wire('a',[0,10],[20,10]),wire('b',[10,0],[10,20])];
  const r=exportKiCad(p);assert.equal(r.topology.nets.length,2);
  assert.equal((r.schematic.match(/\(wire \(pts/g)||[]).length,2);
  assert.equal((r.schematic.match(/\(junction \(at/g)||[]).length,0);
});
test('orphan junctions are rejected',()=>{const p=empty();p.junctions=[j('j1',[10,10])];assert.throws(()=>buildTopology(p),/Orphan/);});
test('invalid PCB footprint on ground or voltage source denied',()=>{const p=fixture();p.components[0].footprint='Package:SOIC-8';assert.throws(()=>exportKiCad(p),/cannot have invented footprint/);});
