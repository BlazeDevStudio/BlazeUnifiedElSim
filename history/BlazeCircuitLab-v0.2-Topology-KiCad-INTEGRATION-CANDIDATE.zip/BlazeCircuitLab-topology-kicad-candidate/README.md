# Blaze CircuitLab — v0.2 topology/KiCad *integration candidate*

**Not an update to Blaze CircuitLab 0.1.0 Alpha. Not an APK. Not a replacement application.**

## Why this exists

The original `BlazeCircuitLab-0.1.0-alpha.zip` was **not attached in the current conversation, found in the accessible ChatGPT file library, or located in the connected Google Drive / GitHub checks**. The original `simulator.js`, `app.js`, Android wrapper, projects and test suites could therefore not be inspected or changed. Instead of inventing an alpha baseline or overwriting it, this package contains a small stand-alone, dependency-free ES module candidate intended for careful integration **after the real alpha source is available**.

Nothing in this package is represented as having been integrated with or tested against the original alpha.

## Included

- `src/topology.mjs`: version-2 project graph schema, validation, fixed pin geometry, union/find net calculation, explicit-junction semantics and safe refusal of ambiguous T/overlapping wires.
- `src/kicad.mjs`: native KiCad 9-targeting S-expression candidate for a small symbol set; self-contained cache definitions, local custom symbol library, pin UUIDs, project associations, no fictitious footprints.
- `src/generate-sample.mjs`: self-contained, offline sample-file generator.
- `samples/series-led.project.json`: sample 5 V + 330-ohm + LED series circuit with ground.
- `samples/series-led-kicad/`: generated `.kicad_sch`, `.kicad_sym`, `sym-lib-table`, source connectivity JSON and export warnings.
- `tests/`: Node.js unit tests and a second, independent exporter-output S-expression reader for pin/net connectivity comparison.
- `report/`: recorded test execution log and development status.

## Tested

Run offline with Node.js >=18:

```sh
npm test
npm run sample
```

As executed in the provided environment: **22/22 module tests passed**. Tests check disconnected crossings, joined junctions, T-junction rejection, collinear overlapping-wire refusal, pin placement, 90-degree rotations, malformed input, duplicate IDs, stable generated UUIDs, determinism, warning behavior, graph parity and serialized S-expression reconstruction.

**Not tested:** Original alpha tests/examples; original DC/AC numerical solver; WebView/Android lifecycle; physical devices; original JSON-project migration; KiCad application's ability to open/ERC/export the sample; native `kicad-cli` (not available); KiCad's own netlist extraction; KiCad PCB import. A syntax-balanced file and matching independent reader are not proof of KiCad compatibility.

## Project schema (candidate only)

```json
{
 "schemaVersion": 2,
 "name": "MyCircuit",
 "components": [{"id":"resistor-stable-id", "ref":"R1", "type":"resistor", "value":"330", "at":[40.64,25.4], "rotation":0}],
 "wires": [{"id":"wire-stable-id", "from":[35.56,25.4], "to":[25.4,25.4]}],
 "junctions": []
}
```

Coordinates are KiCad schematic millimeters, Y-positive down. Supported candidate symbol types are `resistor`, `led` (pin 1 cathode, pin 2 anode), `vdc` (pin 1 positive, pin 2 negative), and `ground` (one pin; all grounds electrically common). Only 0/90/180/270 degree rotations and orthogonal wires are supported. No schematic editing/UI, numerical solver or MCU emulation is implemented here.

Explicit junctions join crossing wires; perpendicular interior/interior crossings without junctions are disconnected. Wires sharing endpoints join. T intersections lacking junctions are refused because conversion might introduce an unintended connection. Collinear overlaps are refused pending normalization in the real editor. Pin-in-wire-interior connections require a junction. These are **candidate topology rules requiring review against the actual alpha UI and KiCad semantics**.

## KiCad export details

The exporter targets the KiCad 9-era schematic S-expression version `20250114`, and includes local `BlazeCircuitLab` symbol definitions and a `sym-lib-table` in the sample directory. Source project refs/values and pin geometry are explicitly mapped. The exporter does not generate PCB files or fabricate physical footprints; user-supplied footprints are not automatically considered valid. Ideal voltage sources and virtual ground are on-board-disabled.

The symbols are preliminary original drawings, **not official KiCad library symbols or verified KiCad native opens**. The GND symbol uses a power symbol definition; actual KiCad netlist behavior needs CLI validation. A successful CLI ERC with no footprint errors is not a substitute for netlist parity. The file should not be used for fabrication without native verification.

Test this generated sample with a real installed KiCad 9/10 CLI:

```sh
kicad-cli sch export netlist -o series-led.net series-led.kicad_sch
kicad-cli sch erc -o series-led-erc.txt series-led.kicad_sch
```

Then inspect the real output, compare the three expected nets to `net-graph.json` (pin names and references are explicit), and open in Eeschema. The native CLI and app were **not available during this package's creation**. Treat errors as blockers, not approvals.

## Integration prerequisites (mandatory)

1. Obtain the **original** `BlazeCircuitLab-0.1.0-alpha.zip` (or an exact verified source repository/archive). Preserve an unmodified copy, hash it, inspect its contents, and run its original tests.
2. Map original `app.js` wire/component/junction formats to candidate schema v2 using a non-destructive, versioned migration. **Do not blindly rewrite old projects**. Preserve source IDs and ownership and add backup before migration.
3. Update editor/simulation/export to use one authoritative model in memory; replace any divergent electrical-net inference only after regression verification.
4. Test with actual alpha example circuits; do not trust the sample's abstract LED behavior as a substitute for the solver.
5. Validate KiCad files with a real KiCad CLI and editor, record real output/evidence. Resolve syntax/symbol problems before marking `.kicad_sch` as available in the Android Export Center.
6. Add Android Storage Access Framework export and UI integration, then build an actual signed/tested APK through a real Android SDK; this package has no Android installable.

No original application source files were altered. No GitHub writes, branches, commits or PRs were made. No Codex used.

## References

KiCad schematic S-expression developer specification: https://dev-docs.kicad.org/en/file-formats/sexpr-schematic/

KiCad file format documentation: https://dev-docs.kicad.org/en/file-formats/

## License/provenance

Original bespoke candidate code generated for the user; includes no copied KiCad/EveryCircuit/Altium source code, artwork or proprietary assets. Native KiCad file format and project artifacts are interoperability targets; no official endorsement implied.
