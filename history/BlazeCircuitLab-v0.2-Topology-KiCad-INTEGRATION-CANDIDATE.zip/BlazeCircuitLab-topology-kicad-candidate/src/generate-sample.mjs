import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {exportKiCad,assertKiCadSexpr} from './kicad.mjs';
const project=JSON.parse(readFileSync(new URL('../samples/series-led.project.json',import.meta.url)));
const output=exportKiCad(project); assertKiCadSexpr(output.schematic);
const sampleDir=new URL('../samples/series-led-kicad/',import.meta.url);mkdirSync(sampleDir,{recursive:true});
for(const [filename,body] of Object.entries({
  'series-led.kicad_sch':output.schematic,
  'BlazeCircuitLab.kicad_sym':output.library,
  'sym-lib-table':output.table,
  'net-graph.json':JSON.stringify(output.topology.nets,null,2)+'\n',
  'export-warnings.json':JSON.stringify(output.warnings,null,2)+'\n'
}))writeFileSync(new URL(filename,sampleDir),body);
console.log(`Generated sample schematic, ${output.uuidCount} UUIDs, ${output.topology.nets.length} nets; native KiCad NOT run.`);
