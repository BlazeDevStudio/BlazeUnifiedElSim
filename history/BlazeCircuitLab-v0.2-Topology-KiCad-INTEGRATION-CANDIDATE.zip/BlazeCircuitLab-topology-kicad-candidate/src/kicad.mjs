import {SYMBOLS,buildTopology,splitWires,globalPin,validateProject} from './topology.mjs';

// This is a KiCad-9-targeting S-expression serializer candidate, NOT native-KiCad validated.
const fmt = n => {const s=Number(n.toFixed(6)).toString();return s==='-0'?'0':s;};
const quote = s => {
  if (typeof s!=='string'||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(s)) throw Error('Invalid KiCad text');
  return '"'+s.replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\n/g,'\\n').replace(/\t/g,'\\t')+'"';
};
// Deterministic local UUID generator. 128-bit noncryptographic hashing with duplicate detection.
// Imported project object identifiers are preserved separately in the native JSON.
function uuid(label) {
  const seed= [2166136261,2166136261^0x9e3779b9,2166136261^0x85ebca6b,2166136261^0xc2b2ae35];
  const b = new TextEncoder().encode(label);
  let s=seed.map((v,i)=>v^(i*0x45d9f3b));
  for(const c of b) s=s.map((x,i)=>Math.imul(x^((c+i*13)&255),16777619)>>>0);
  const z=s.map(v=>v.toString(16).padStart(8,'0')).join('');
  return `${z.slice(0,8)}-${z.slice(8,12)}-4${z.slice(13,16)}-a${z.slice(17,20)}-${z.slice(20,32)}`;
}
const pt=p=>`(xy ${fmt(p[0])} ${fmt(p[1])})`;
const stroke='(stroke (width 0) (type default))';
const effects='(effects (font (size 1.27 1.27)))';
const hidden='(effects (font (size 1.27 1.27)) (hide yes))';
const pin=(type,name,num,x,y,ang,length=2.54)=>`(pin ${type} line (at ${fmt(x)} ${fmt(y)} ${ang}) (length ${fmt(length)}) (name ${quote(name)} ${effects}) (number ${quote(num)} ${effects}))`;
const line=pts=>`(polyline (pts ${pts.map(pt).join(' ')}) (stroke (width 0.254) (type default)) (fill (type none)))`;
const symbols = {
  resistor: {
    body: `(rectangle (start -2.54 1.27) (end 2.54 -1.27) (stroke (width 0.254) (type default)) (fill (type none)))`,
    pins: [pin('passive','~','1',-5.08,0,0),pin('passive','~','2',5.08,0,180)]
  },
  led: {
    body: [line([[1.27,1.27],[1.27,-1.27],[-1.27,0],[1.27,1.27]]),line([[-1.27,1.27],[-1.27,-1.27]]),line([[0,1.5],[1.25,2.75]]),line([[1.25,1.5],[2.5,2.75]])].join(' '),
    pins: [pin('passive','K','1',-5.08,0,0),pin('passive','A','2',5.08,0,180)]
  },
  vdc: {
    body: `(circle (center 0 0) (radius 2.54) (stroke (width 0.254) (type default)) (fill (type none))) ${line([[-1.27,0],[1.27,0]])} ${line([[0,-1.27],[0,1.27]])}`,
    pins: [pin('power_out','+','1',-5.08,0,0),pin('power_out','-','2',5.08,0,180)]
  },
  ground: {
    body: `${line([[0,0],[0,-1.27]])} ${line([[-2.54,-1.27],[2.54,-1.27]])} ${line([[-1.65,-1.9],[1.65,-1.9]])} ${line([[-0.7,-2.5],[0.7,-2.5]])}`,
    pins: [pin('power_in','GND','1',0,0,90,0)]
  }
};
function libSymbol(type, prefix=true){
  const s=SYMBOLS[type],shape=symbols[type];
  const name=prefix?s.libId:s.libId.split(':')[1];
  const short=s.libId.split(':')[1];
  const ref=s.prefix==='\#PWR'?'#PWR':s.prefix;
  return `(symbol ${quote(name)} ${type==='ground'?'(power) ':''}(pin_numbers (hide yes)) (pin_names (offset 0) (hide yes)) (in_bom ${type==='ground'?'no':'yes'}) (on_board ${['ground','vdc'].includes(type)?'no':'yes'})
    (property "Reference" ${quote(ref)} (at 0 5.08 0) ${effects})
    (property "Value" ${quote(short)} (at 0 -5.08 0) ${effects})
    (symbol ${quote(`${short}_0_1`)} ${shape.body})
    (symbol ${quote(`${short}_1_1`)} ${shape.pins.join(' ')})
  )`;
}
const prop=(k,v,x,y,hide=false)=>`(property ${quote(k)} ${quote(v)} (at ${fmt(x)} ${fmt(y)} 0) ${hide?hidden:effects})`;
export function exportKiCad(project){
  const topology=buildTopology(project);
  const used=new Set();
  function uid(label){const u=uuid(`${project.name}|${label}`);if(used.has(u))throw Error('Deterministic UUID collision');used.add(u);return u;}
  const root=uid('root');
  const types=[...new Set(project.components.map(c=>c.type))].sort();
  const embedded=types.map(type=>libSymbol(type,true)).join('\n');
  const junctions=project.junctions.map(j=>`(junction (at ${fmt(j.at[0])} ${fmt(j.at[1])}) (diameter 0) (color 0 0 0 0) (uuid ${quote(uid('junction:'+j.id))}))`).join('\n');
  const wires=splitWires(project).map(w=>`(wire (pts ${pt(w.from)} ${pt(w.to)}) ${stroke} (uuid ${quote(uid(`wire:${w.sourceId}:${w.part}`))}))`).join('\n');
  const components=[...project.components].sort((a,b)=>a.ref.localeCompare(b.ref)).map(c=>{
    const s=SYMBOLS[c.type],x=c.at[0],y=c.at[1],angle=c.rotation||0;
    const pins=s.pins.map(p=>`(pin ${quote(p.number)} (uuid ${quote(uid('pin:'+c.id+':'+p.number))}))`).join('\n');
    const footprint = c.footprint ? prop('Footprint',c.footprint,x,y, true) : prop('Footprint','',x,y,true);
    return `(symbol (lib_id ${quote(s.libId)}) (at ${fmt(x)} ${fmt(y)} ${angle}) (unit 1) (in_bom ${c.type==='ground'?'no':'yes'}) (on_board ${['ground','vdc'].includes(c.type)?'no':'yes'}) (dnp no)
       (uuid ${quote(uid('symbol:'+c.id))})
       ${prop('Reference',c.ref,x,y-8)}
       ${prop('Value',c.value,x,y+8)}
       ${footprint}
       ${pins}
       (instances (project ${quote(project.name)} (path ${quote('/'+root)} (reference ${quote(c.ref)}) (unit 1))))
     )`;
  }).join('\n');
  const schematic=`(kicad_sch
  (version 20250114)
  (generator "blaze_circuitlab")
  (generator_version "0.2-topology-candidate")
  (uuid ${quote(root)})
  (paper "A4")
  (lib_symbols ${embedded})
  ${junctions}
  ${wires}
  ${components}
  (sheet_instances (path "/" (page "1")))
)\n`;
  const library=`(kicad_symbol_lib (version 20231120) (generator "blaze_circuitlab")
${types.map(t=>libSymbol(t,false)).join('\n')}
)\n`;
  const table=`(sym_lib_table (lib (name "BlazeCircuitLab") (type "KiCad") (uri "\${KIPRJMOD}/BlazeCircuitLab.kicad_sym") (options "") (descr "Blaze CircuitLab candidate symbols")))\n`;
  // This warnings list is a hard stop for physical handoff.
  const warnings=project.components.flatMap(c=>{
    if(['ground','vdc'].includes(c.type))return [`${c.ref}: simulation/power object; no PCB footprint assigned`];
    if(!c.footprint)return [`${c.ref}: no physical footprint assigned`];
    return [`${c.ref}: user-supplied footprint has not been validated against a KiCad footprint library`];
  });
  return {schematic,library,table,topology,warnings,uuidCount:used.size};
}
export function assertKiCadSexpr(text){
  if(!text.startsWith('(kicad_sch'))throw Error('Missing KiCad schematic root');
  let balance=0,inString=false,escaped=false;
  for(const c of text){
    if(inString){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')inString=false;}
    else if(c==='"')inString=true;else if(c==='(')balance++;else if(c===')'){balance--;if(balance<0)throw Error('Unbalanced parenthesis');}
  }
  if(balance||inString||escaped)throw Error('Malformed S-expression');
  return true;
}
