Blaze CircuitLab KiCad 9 experimental schematic export.
Open the .kicad_sch in KiCad 9; local footprint table in fp-lib-table.
All seven existing circuit classes are exported as editable BlazeCircuitLab symbols.
There is no firmware emulation, no PCB board file and no routed copper included.
Physical footprint geometry is preliminary; verify sizes, ERC and DRC before manufacture.
WARNINGS:
V1: simulation/power object; not a physical PCB footprint
R1: assigned footprint is not verified in a KiCad library
D1: assigned footprint is not verified in a KiCad library
G1: simulation/power object; not a physical PCB footprint
KiCad 9 target: native KiCad opening and ERC not performed in this environment
