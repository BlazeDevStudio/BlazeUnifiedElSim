# Blaze CircuitLab v0.2.8 — Native Android controlled-source integration

This is an incremental continuation of the **v0.2.7 native Kotlin project**. Runtime UI is Android `Canvas`, **not HTML/WebView**. The 0.1.0 HTML alpha remains unchanged under `legacy/`; the v0.2.7 README remains in `docs/` as historical evidence.

## Implemented in this source milestone

- A **four-terminal voltage-controlled voltage source (VCVS)** with IN+, IN−, OUT+, OUT− and finite gain `V(out+)-V(out−) = gain*(V(in+)-V(in−))`.
- Correct MNA dependent-source current unknown and algebraic voltage constraint, with no fictitious input conductance.
- Four searchable offline gain presets, native Canvas schematic symbol and placement button, editable gain, output-voltage/current readout, and gain-10 sample circuit.
- Experimental KiCad symbol (4 numbered pins, **simulation-only, no PCB footprint**) and SPICE dependent `E` element.
- Sample circuit plus simulator regression tests covering amplifier gain, source current, floating inputs, negative feedback, pin mapping, SPICE ordering, KiCad structure and fail-closed physical assignment.
- Original simulator, PCB preview/manual-routing, Arduino/ESP pin-planning, import/export and older example circuits retained. **Project schema remains v8**; no migration is necessary for the new enum type.

### Important modeling boundaries

The VCVS is a controlled linear source, **not a complete op-amp**: no supply pins, voltage/current limiting, saturation, slew rate, bandwidth, offset, or thermal/noise behavior. It can supply arbitrary modeled power; physical safety must never be inferred. For a real op-amp project select a real part, model, and datasheet; do not assign a fabricated footprint to the VCVS.

The existing MOSFET, diode, LED, NPN and other models also retain their documented approximations. KiCad, SPICE and PCB handoffs are **experimental**, and no imported vendor KiCad libraries were copied. The Android app requires no network permission, account or root.

## Build and test

From this directory with JDK 17 and Kotlin CLI available:

```bash
bash tools/run-jvm-smoke.sh
bash tools/check-native-syntax-with-stubs.sh
```

The first is the actual Kotlin JVM core regression suite. The second compiles Android-facing Kotlin code only against temporary test stubs — **not** the Android SDK. After installing Android SDK platform 35, Build Tools 35.0.0 and Gradle 8.9 in a development environment:

```bash
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
```

If the real build succeeds, `app/build/outputs/apk/debug/app-debug.apk` is the expected debug output. This archive does **not** contain a built APK. The included GitHub Actions workflow is a build candidate, not proof a CI run succeeded. Check launch, rotate, wiring, library insertion, negative feedback, offline save/load, exports, and crash recovery on an actual Android device.

## Honest release gates

- Kotlin numerical/core tests: see `docs/TEST-EVIDENCE-v0.2.8.txt`.
- Android Kotlin API-stub compilation: source check only.
- Android SDK build and physical device: **not executed** here (SDK and Gradle unavailable and downloads DNS-blocked).
- KiCad CLI/ERC and ngspice: **not executed** here.
- Full EveryCircuit + KiCad + Altium + Arduino amalgamation: **not achieved**. Full op-amp models, PCB fabrication DRC, and real MCU firmware emulation remain future work.

No Codex was used.
