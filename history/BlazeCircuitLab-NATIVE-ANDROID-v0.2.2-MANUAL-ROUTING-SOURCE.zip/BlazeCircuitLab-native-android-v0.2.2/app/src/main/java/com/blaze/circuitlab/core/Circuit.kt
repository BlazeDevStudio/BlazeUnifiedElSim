package com.blaze.circuitlab.core

import java.util.UUID
import kotlin.math.roundToInt

/** Native authoritative electrical project data. Coordinates are original alpha SVG grid units. */
data class Point(val x: Int, val y: Int) {
    fun snapped(): Point = Point((x / 12.0).roundToInt() * 12, (y / 12.0).roundToInt() * 12)
}

enum class PartType { V, AC, R, C, LED, SW, GND }

data class Part(
    val uuid: String = UUID.randomUUID().toString(),
    var ref: String,
    val type: PartType,
    var x: Int,
    var y: Int,
    var value: Double = defaults(type),
    var frequency: Double = 2.0,
    var closed: Boolean = true,
    var rotation: Int = 0,
    var footprint: String? = null
) {
    companion object {
        fun defaults(type: PartType): Double = when (type) {
            PartType.V, PartType.AC -> 5.0
            PartType.R -> 330.0
            PartType.C -> 0.001
            PartType.LED -> 2.0
            PartType.SW -> 1.0
            PartType.GND -> 0.0
        }
    }
    /** Left/right terminal order is also numerical-solver current-reference order. */
    fun pins(): List<Point> {
        val local = if (type == PartType.GND) listOf(Point(0, -24)) else listOf(Point(-48, 0), Point(48, 0))
        return local.map { p -> when (((rotation % 360) + 360) % 360) {
            0 -> Point(x + p.x, y + p.y)
            90 -> Point(x - p.y, y + p.x)
            180 -> Point(x - p.x, y - p.y)
            270 -> Point(x + p.y, y - p.x)
            else -> throw IllegalArgumentException("Rotation must be 0, 90, 180 or 270")
        } }
    }
    fun clonePart(): Part = copy()
}

data class Wire(
    val uuid: String = UUID.randomUUID().toString(),
    var a: Point,
    var b: Point
)

data class Junction(val uuid: String = UUID.randomUUID().toString(), val at: Point)

data class Circuit(
    val version: Int = 4,
    var title: String = "Untitled Circuit",
    val parts: MutableList<Part> = mutableListOf(),
    val wires: MutableList<Wire> = mutableListOf(),
    val junctions: MutableList<Junction> = mutableListOf(),
    val board: BoardLayout = BoardLayout()
) {
    fun detached(): Circuit = Circuit(version, title, parts.map { it.clonePart() }.toMutableList(),
        wires.map { it.copy() }.toMutableList(), junctions.map { it.copy() }.toMutableList(), board.detached())

    fun validate() {
        require(version == 4) { "Unknown circuit schema version" }
        require(parts.size <= 200 && wires.size <= 700 && junctions.size <= 700) { "Circuit resource limit" }
        require(title.length in 1..100) { "Invalid project title" }
        require((parts.map { it.uuid } + wires.map { it.uuid } + junctions.map { it.uuid }).distinct().size == parts.size + wires.size + junctions.size) { "Duplicate UUID" }
        require(parts.map { it.ref }.distinct().size == parts.size) { "Duplicate reference designator" }
        for (p in parts) {
            require(p.x in -100000..100000 && p.y in -100000..100000) { "Invalid component position" }
            require(p.value.isFinite() && p.frequency.isFinite()) { "Nonfinite component value" }
            require(p.ref.length in 1..32) { "Invalid reference designator" }
            require((p.footprint?.length?:0)<=160){"Footprint name exceeds 160 characters"}
            require(p.rotation in setOf(0,90,180,270)) { "Unsupported rotation" }
            when(p.type) {
                PartType.R -> require(p.value in 1e-3..1e10) { "Resistor ${p.ref} is outside modeled range" }
                PartType.C -> require(p.value in 1e-15..1e3) { "Capacitor ${p.ref} is outside modeled range" }
                PartType.LED -> require(p.value in .01..100.0) { "LED forward voltage is outside modeled range" }
                PartType.AC -> require(p.frequency in .001..1e7 && kotlin.math.abs(p.value)<=1e6) { "AC source is outside modeled range" }
                PartType.V -> require(kotlin.math.abs(p.value)<=1e6) { "Voltage source is outside modeled range" }
                else -> Unit
            }
        }
        for (w in wires) {
            require(w.a != w.b && (w.a.x == w.b.x || w.a.y == w.b.y)) { "Wires must be nonzero orthogonal segments" }
            require(listOf(w.a.x,w.a.y,w.b.x,w.b.y).all{it in -100000..100000}){"Wire outside supported canvas"}
        }
        require(junctions.map { it.at }.distinct().size == junctions.size) { "Duplicate junction coordinate" }
        require(junctions.all{it.at.x in -100000..100000 && it.at.y in -100000..100000}){"Junction outside supported canvas"}
    }
}

object DemoCircuits {
    fun led(): Circuit = Circuit(title="LED Current Limiter", parts=mutableListOf(
        part("V1",PartType.V,216,180,5.0),part("R1",PartType.R,384,180,330.0),
        part("D1",PartType.LED,552,180,2.0),part("G1",PartType.GND,240,384,0.0)
    ), wires=mutableListOf(w(264,180,336,180),w(432,180,504,180),w(600,180,672,180),
        w(672,180,672,360),w(672,360,168,360),w(168,360,168,180)),
        junctions=mutableListOf(Junction(at=Point(240,360))))
    fun rc(): Circuit {
        val c=led();c.title="RC Charge and Discharge";
        c.parts[0]=part("AC1",PartType.AC,216,180,5.0).also { it.frequency=.5 }
        c.parts[1]=part("R1",PartType.R,384,180,1000.0)
        c.parts[2]=part("C1",PartType.C,552,180,.001)
        return c
    }
    fun switched(): Circuit = Circuit(title="Interactive LED Switch", parts=mutableListOf(
        part("V1",PartType.V,168,180,9.0),part("S1",PartType.SW,312,180,1.0),
        part("R1",PartType.R,456,180,470.0),part("D1",PartType.LED,600,180,2.0),
        part("G1",PartType.GND,240,384,0.0)
    ), wires=mutableListOf(w(216,180,264,180),w(360,180,408,180),w(504,180,552,180),w(648,180,720,180),
        w(720,180,720,360),w(720,360,120,360),w(120,360,120,180)),
        junctions=mutableListOf(Junction(at=Point(240,360))))
    private fun part(r:String,t:PartType,x:Int,y:Int,v:Double) = Part(uuid=UUID.nameUUIDFromBytes("alpha:$r:$x:$y".toByteArray()).toString(),ref=r,type=t,x=x,y=y,value=v)
    private fun w(ax:Int,ay:Int,bx:Int,by:Int)=Wire(a=Point(ax,ay),b=Point(bx,by))
}
