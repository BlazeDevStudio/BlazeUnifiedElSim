# Blaze CircuitLab — Native Android v0.2.2 (development source)

**This continues the native Android 0.2.1 project.** The primary app is Kotlin + Android `Canvas`, **not** an HTML/WebView simulator. The original alpha HTML remains byte-for-byte intact under `legacy/` solely as an engineering reference. No Codex was used.

## New in v0.2.2: manual single-layer PCB routing preview

- Native PCB screen has **Move PCB** and **Route pads** tools; select two physical pads on the *same schematic net* to propose a front-copper (`F.Cu`) connection. The engine tries straight or two orthogonal L paths and rejects unsafe/unsupported geometries.
- Routes refer to stable **part UUID + pad number**, not temporary numerical net IDs. All pad nets are resolved from the same `Topology.build` used by the electrical solver and KiCad schematic exporter.
- Routes are green, remaining **unrouted** airwires are orange. Existing routes reduce the ratsnest only when pad endpoints actually connect. **Remove last route** and the existing project-level Undo are available.
- Lightweight *approximate* checks reject opposite-net pad contact, different-net track crossings/spacing, out-of-board copper, non-orthogonal routes, unsupported layers and track widths, orphan pads and changed footprint geometry.
- Schema **version 4** stores PCB routes, bends, widths and layer. Native v3 and older native v2 and alpha v1 import paths remain available in source; **Android JSON runtime verification is still pending**.
- Schematic edits are revalidated against PCB routes and rolled back if they would corrupt the board; deletion of a schematic component also removes routes anchored to it.
- Existing solver, alpha circuit demos, and KiCad schematic serialization are retained. A new Gradle/JUnit test suite is included for execution in Android CI.

**Important limitations:** These tracks are modeled copper in a **preview only**, not manufacturing-validated copper. Pad centers are approximations; there is **no** true KiCad footprint geometry validation, via/ground-zone support, polygon copper, proper multilayer router, full DRC, Gerber, Excellon, or KiCad PCB export. Even a board with zero remaining airwires must **not** be sent to fabrication.

## Native Android usage (once built and verified)

1. Start with LED demo, enter **PCB Placement**, assign an `0805 resistor` footprint to `R1` and `LED 3mm` footprint to `D1`.
2. Tap **Route pads** and then tap resistor **pad 2** and LED **pad 2**. These are connected to the same authoritative schematic net in the demo. A green F.Cu path should replace the orange airwire.
3. Tap **Move PCB** to reposition components (unsafe changes are rejected). **Remove last route** removes the latest copper path; Undo restores the previous project snapshot.
4. Save native JSON through the Android Storage Access Framework. Reimport to check all component identities and copper routes survive. On-device acceptance remains required.

## Build and verification

**Build prerequisites:** Android SDK Platform 35, Build Tools 35.0.0, JDK 17, Gradle 8.9, AGP 8.7.3, Kotlin Android plugin 1.9.25. Gradle wrapper is not bundled. The Android package has no Internet permission and does not require an online backend for circuit operations.

```sh
# In Android Studio terminal, after installing Gradle and Android SDK:
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
# Expected output on success (NOT produced in this environment):
# app/build/outputs/apk/debug/app-debug.apk
```

A GitHub Actions workflow is provided under `.github/workflows/android-debug.yml`; **it has not been run**, and the existence of a workflow is not proof of a built APK.

Platform-independent locally executed verification:

```sh
bash tools/run-jvm-smoke.sh                # 34/34 Kotlin core checks passed
bash tools/check-native-syntax-with-stubs.sh # source checks ONLY, not Android compilation
```

**Verification still required before any APK or product claim:** Compile against Android SDK, run Gradle JUnit tests, install and launch on real ARM64 Android and emulator, exercise rotation/touch/route errors and JSON migrations, test offline persistence and import/export, and validate exported schematics in a native KiCad application (ERC and netlist comparison).

## Project layout

- `core/Circuit.kt`, `core/Topology.kt` — authoritative schematic and electrical connectivity.
- `core/MnaSolver.kt` — educational numerical solver preserving original alpha behavior.
- `core/KiCad.kt` — experimental KiCad schematic exporter (native KiCad application validation pending).
- `core/Board.kt`, `core/BoardRouting.kt` — footprint pin mapping, placement, manual copper model, clearance checks and residual ratsnest.
- `MainActivity.kt`, `NativeCircuitView.kt`, `NativeBoardView.kt`, `ProjectJson.kt` — Android-native UI and local storage.
- `tools/JvmSmoke.kt` — standalone Kotlin tests; `app/src/test` — Android Gradle/JUnit tests (not yet executed).
- `legacy/` — unchanged user-supplied HTML alpha, excluded from app runtime.
- `docs/` — engineering status, historical notes, checksums and test evidence.

## Next mandatory release gates

1. Run Android SDK/Gradle CI and obtain **real debug APK + test logs**, then real Android launch/touch/SAF acceptance.
2. Perform **real KiCad** schematic opening, ERC and netlist equivalence verification.
3. Validate real footprint geometry and implement native KiCad board export, then progressively extend manufacturing-grade DRC, layers, vias, zones and fabrication outputs.
4. Separately implement real MCU firmware execution; **no Arduino/ESP instruction emulation currently exists**.

The app is original Blaze code, not a copy of any proprietary EveryCircuit, Altium, Arduino or KiCad interface or assets. **This is source development, not an installable or production-ready release.**
