plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.blaze.circuitlab"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.blaze.circuitlab"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.2.1-native-pcb-preview"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
