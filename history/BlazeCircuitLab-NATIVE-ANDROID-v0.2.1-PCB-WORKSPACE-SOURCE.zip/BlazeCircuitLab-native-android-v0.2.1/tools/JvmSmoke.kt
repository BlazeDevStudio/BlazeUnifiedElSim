import com.blaze.circuitlab.core.*
import kotlin.math.abs

fun near(actual:Double,expected:Double,eps:Double=1e-4) {
    check(abs(actual-expected)<eps) { "Expected $expected, got $actual" }
}
var checks=0
fun test(name:String,fn:()->Unit){fn();checks++;println("PASS $name")}
fun main() {
    test("original LED demo and DC current") {
        val c=DemoCircuits.led();val r=MnaSolver.step(c)
        check(r.ok){r.message};near(r.currentIn(c.parts[1])!!,3.0/342.0,5e-5)
        near(r.voltageAcross(c.parts[0])!!,-5.0)
    }
    test("original switch closed and opened"){
        val c=DemoCircuits.switched()
        val on=MnaSolver.step(c);check(on.ok){on.message}
        val onCurrent=on.currentIn(c.parts[2])!!
        c.parts.first{it.type==PartType.SW}.closed=false
        val off=MnaSolver.step(c);check(off.ok){off.message}
        check(kotlin.math.abs(off.currentIn(c.parts[2])!!)<1e-6)
        check(onCurrent>.001)
    }
    test("original RC demo transient"){
        val c=DemoCircuits.rc();var state=MnaSolver.State()
        repeat(100){i-> val s=MnaSolver.step(c,state,0.01,(i+1)*0.01);check(s.ok){s.message};state=s.state }
        check(state.capacitorVoltage.isNotEmpty())
        check(state.nodeVoltage.values.all{it.isFinite()})
    }
    test("crossing wires without junction not connected") {
        val c=Circuit(title="cross",wires=mutableListOf(Wire(a=Point(-48,0),b=Point(48,0)),Wire(a=Point(0,-48),b=Point(0,48))))
        val t=Topology.build(c);check(t.wireNet.values.distinct().size==2)
        c.junctions.add(Junction(at=Point(0,0)))
        val joined=Topology.build(c);check(joined.wireNet.values.distinct().size==1)
    }
    test("unmarked T intersection is rejected"){
        val c=Circuit(wires=mutableListOf(Wire(a=Point(-48,0),b=Point(48,0)),Wire(a=Point(0,-48),b=Point(0,0))))
        check(runCatching{Topology.build(c)}.isFailure)
        c.junctions.add(Junction(at=Point(0,0)))
        check(Topology.build(c).wireNet.values.distinct().size==1)
    }
    test("end-to-end segment connection"){
        val c=Circuit(wires=mutableListOf(Wire(a=Point(-48,0),b=Point(0,0)),Wire(a=Point(0,0),b=Point(48,0))))
        check(Topology.build(c).wireNet.values.distinct().size==1)
    }
    test("duplicate refs validation"){
        val c=DemoCircuits.led();c.parts[1].ref=c.parts[0].ref
        check(runCatching{Topology.build(c)}.isFailure)
    }
    test("no GND -> diagnostic"){
        val c=DemoCircuits.led();c.parts.removeAll{it.type==PartType.GND}
        check(MnaSolver.step(c).message.contains("GND"))
    }
    test("open disconnected circuit -> floating diagnostic"){
        val c=DemoCircuits.led();c.wires.clear();c.junctions.clear()
        check(!MnaSolver.step(c).ok)
    }
    test("KiCad serializer generated syntax"){
        val c=DemoCircuits.led();val exp=KiCad.export(c)
        check(KiCad.balanced(exp.schematic));check(exp.schematic.contains("(kicad_sch"))
        check(exp.schematic.contains("(lib_symbols"))
        check(exp.schematic.contains("\"BlazeCircuitLab:LED\""))
        check(exp.schematic.contains("(junction "))
        check(exp.warnings.isNotEmpty())
        java.io.File("tools/LED_Current_Limiter.kicad_sch").writeText(exp.schematic)
    }
    test("KiCad unsupported component fails explicitly"){
        val c=DemoCircuits.rc();check(runCatching{KiCad.export(c)}.isFailure)
    }
    test("KiCad deterministic output"){
        val c=DemoCircuits.led();check(KiCad.export(c).schematic==KiCad.export(c).schematic)
    }
    test("LED branch current matches original HTML alpha") {
        val c=DemoCircuits.led();val r=MnaSolver.step(c,dt=.015,time=.015)
        near(r.currentIn(c.parts[1])!!,.008771929825300092,1e-9)
    }
    test("Switch branch current matches original HTML alpha") {
        val c=DemoCircuits.switched();val r=MnaSolver.step(c,dt=.015,time=.015)
        near(r.currentIn(c.parts[2])!!,.01452131521679579,1e-9)
    }
    test("RC first timestep matches original HTML alpha") {
        val c=DemoCircuits.rc();val r=MnaSolver.step(c,dt=.015,time=.015)
        near(r.currentIn(c.parts[1])!!,.00023205148132880336,1e-9)
    }
    test("PCB data mapping uses authoritative net graph") {
        val c=DemoCircuits.led();val r=c.parts[1]
        val pads=BoardContract.resolvePads(c,listOf(PhysicalPadMapping(r.uuid,"Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal",mapOf("1" to 0,"2" to 1))))
        check(pads.size==2 && pads[0].electricalNet!=pads[1].electricalNet)
    }
    test("PCB mapping rejects invented voltage-source footprint") {
        val c=DemoCircuits.led();val p=c.parts[0]
        check(runCatching{BoardContract.resolvePads(c,listOf(PhysicalPadMapping(p.uuid,"Connector_Generic:Conn_01x02",mapOf("1" to 0,"2" to 1))))}.isFailure)
    }
    test("PCB mapping rejects missing terminal mapping") {
        val c=DemoCircuits.led();val p=c.parts[1]
        check(runCatching{BoardContract.resolvePads(c,listOf(PhysicalPadMapping(p.uuid,"Resistor_SMD:R_0805",mapOf("1" to 0))))}.isFailure)
    }
    test("PCB explicit footprint assignment builds one unrouted net") {
        val c=DemoCircuits.led()
        val resistor=c.parts.single{it.ref=="R1"};val led=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,resistor.uuid,"Resistor_SMD:R_0805_2012Metric")
        BoardPlanner.assign(c,led.uuid,"LED_THT:LED_D3.0mm")
        val preview=BoardPlanner.preview(c)
        check(preview.pads.size==4)
        check(preview.airwires.size==1)
        check(preview.airwires.single().a.net==preview.airwires.single().b.net)
        check(preview.warnings.any{it.contains("no physical footprint")})
    }
    test("PCB footprint pin polarity is physical KiCad LED cathode 1 anode 2") {
        val c=DemoCircuits.led();val d=c.parts.single{it.ref=="D1"}
        BoardPlanner.assign(c,d.uuid,"LED_THT:LED_D3.0mm")
        val p=BoardPlanner.preview(c).pads.filter{it.ref=="D1"}.associateBy{it.pad}
        val topology=Topology.build(c)
        check(p.getValue("1").net==topology.net(d,1))
        check(p.getValue("2").net==topology.net(d,0))
    }
    test("PCB rejects impossible position and missing footprint") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        check(runCatching{BoardPlanner.assign(c,r.uuid,"LED_THT:LED_D3.0mm")}.isFailure)
        BoardPlanner.assign(c,r.uuid,"Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal")
        val pl=c.board.placements.single();pl.xMm=0.0
        check(runCatching{BoardPlanner.validate(c)}.isFailure)
    }
    test("PCB layout snapshots are deep copies") {
        val c=DemoCircuits.led();val r=c.parts.single{it.ref=="R1"}
        BoardPlanner.assign(c,r.uuid,"Resistor_SMD:R_0805_2012Metric")
        val snap=c.detached();c.board.placements.single().xMm=20.0
        check(snap.board.placements.single().xMm!=20.0)
    }
    test("PCB has no fabricated copper traces") {
        val c=DemoCircuits.led()
        BoardPlanner.assign(c,c.parts.single{it.ref=="R1"}.uuid,"Resistor_SMD:R_0805_2012Metric")
        check(BoardPlanner.preview(c).airwires.isEmpty())
    }
    println("SUMMARY: $checks/$checks passed")
}
